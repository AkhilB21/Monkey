"""Apollo Core — Renko Integration Module (Pool R)  (v4.5)

Computes Renko-based signals for the Pool R scoring layer.
Pool R is a soft-gate, purely additive layer (max 27 pts).
When Renko confirms candlestick signals, it adds points.
When Renko is silent or inconclusive, it contributes 0.

Signals:
    R1: Renko RSI Oversold Recovery (5 pts, Graded)
    R2: Renko RSI Above 50 (4 pts, Binary)
    R3: Renko Brick Pattern Bullish (3 pts, Graded)
    R4: Renko Trend Alignment (3 pts, Binary)
    R5: Renko 4H Lead Signal (3 pts, Binary)
    R6: Renko No Bearish Divergence (2 pts, Binary)  [v4.4: swing-based]
    R7: Renko Bullish Divergence (4 pts, Binary)      [NEW in v4.4]
    R8: Renko Hidden Bullish Divergence (3 pts, Binary)  [NEW in v4.4]

v4.5: No signal changes; version bump for ranking enrichment.
v4.4 changes:
    - Added find_renko_swings() for proper swing high/low detection.
    - R6 upgraded from crude window-halves to swing-based bearish divergence.
    - R7: Regular Bullish Divergence (price lower low + RSI higher low).
    - R8: Hidden Bullish Divergence (price higher low + RSI lower low).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from apollo_core.indicators import compute_rsi

# ── Divergence parameters (shared across R6, R7, R8) ────────────────
RENKO_SWING_LOOKBACK = 30   # max bricks to search for swing points
RENKO_MIN_SWING_SEP = 5     # minimum bricks between two swing points
RENKO_RSI_DIFF_THRESHOLD = 3.0  # minimum RSI difference to qualify


def compute_renko_bricks(df: pd.DataFrame, brick_size: float | None = None,
                         atr_period: int = 14) -> pd.DataFrame:
    """Compute Renko bricks from OHLC data.

    Parameters
    ----------
    df : pd.DataFrame
        OHLC data with columns: high, low, close.
    brick_size : float or None
        Fixed brick size in price units. If None, uses 1.0x ATR(14).
    atr_period : int
        ATR lookback for automatic brick sizing.

    Returns
    -------
    pd.DataFrame
        Renko brick data with columns: date, open, high, low, close, direction.
        direction: 1 = bullish (green), -1 = bearish (red).
    """
    if brick_size is None:
        # Compute ATR(14)
        high = df["high"]
        low = df["low"]
        close = df["close"]
        prev_close = close.shift(1)
        tr1 = high - low
        tr2 = (high - prev_close).abs()
        tr3 = (low - prev_close).abs()
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=atr_period, min_periods=atr_period).mean()
        brick_size = float(atr.iloc[-1]) if not np.isnan(atr.iloc[-1]) else 0.0

    if brick_size <= 0:
        return pd.DataFrame(columns=["date", "open", "high", "low", "close", "direction"])

    bricks = []
    # Initialize with first close
    price = float(df["close"].iloc[0])
    brick_open = price
    direction = 0  # 0 = undecided

    for _, row in df.iterrows():
        h, l, c = float(row["high"]), float(row["low"]), float(row["close"])

        if direction == 0:
            # First brick: check if we can form one in either direction
            up_bricks = int((h - brick_open) / brick_size)
            down_bricks = int((brick_open - l) / brick_size)
            if up_bricks >= 1 and up_bricks >= down_bricks:
                direction = 1
                brick_open = brick_open
                brick_close = brick_open + brick_size
                bricks.append({"open": brick_open, "high": brick_close,
                              "low": brick_open, "close": brick_close,
                              "direction": 1})
                price = brick_close
            elif down_bricks >= 1:
                direction = -1
                brick_open = brick_open
                brick_close = brick_open - brick_size
                bricks.append({"open": brick_open, "high": brick_open,
                              "low": brick_close, "close": brick_close,
                              "direction": -1})
                price = brick_close
        elif direction == 1:
            # Bullish: need 2 bricks down to reverse, 1 brick up to continue
            up = (h - price) / brick_size
            down = (price - l) / brick_size
            new_bricks_up = int(up)
            reverse_bricks = int(down)
            if reverse_bricks >= 2:
                # Reversal: 2 red bricks
                direction = -1
                for i in range(2):
                    new_open = price - brick_size * (i + 1)
                    new_close = price - brick_size * (i + 2)
                    # Clamp to actual low
                    bricks.append({"open": new_open, "high": new_open,
                                  "low": new_close, "close": new_close,
                                  "direction": -1})
                price = new_close
            elif new_bricks_up >= 1:
                for i in range(new_bricks_up):
                    new_open = price
                    new_close = price + brick_size * (i + 1)
                    bricks.append({"open": new_open, "high": new_close,
                                  "low": new_open, "close": new_close,
                                  "direction": 1})
                price = new_close
        elif direction == -1:
            # Bearish: need 2 bricks up to reverse, 1 brick down to continue
            up = (h - price) / brick_size
            down = (price - l) / brick_size
            new_bricks_down = int(down)
            reverse_bricks = int(up)
            if reverse_bricks >= 2:
                # Reversal: 2 green bricks
                direction = 1
                for i in range(2):
                    new_open = price + brick_size * (i + 1)
                    new_close = price + brick_size * (i + 2)
                    bricks.append({"open": new_open, "high": new_close,
                                  "low": new_open, "close": new_close,
                                  "direction": 1})
                price = new_close
            elif new_bricks_down >= 1:
                for i in range(new_bricks_down):
                    new_open = price
                    new_close = price - brick_size * (i + 1)
                    bricks.append({"open": new_open, "high": new_open,
                                  "low": new_close, "close": new_close,
                                  "direction": -1})
                price = new_close

    result = pd.DataFrame(bricks)
    if len(result) == 0:
        return result
    return result


def compute_renko_rsi(renko_df: pd.DataFrame, period: int = 21) -> pd.Series:
    """Compute RSI on Renko brick close prices.

    Parameters
    ----------
    renko_df : pd.DataFrame
        Renko brick data with 'close' column.
    period : int
        RSI lookback period (default 21).

    Returns
    -------
    pd.Series
        RSI values aligned to the Renko brick index.
    """
    if len(renko_df) < period + 1:
        return pd.Series([np.nan] * len(renko_df), index=renko_df.index)
    return compute_rsi(renko_df["close"], period)


def find_renko_swings(
    renko_df: pd.DataFrame,
    r_idx: int,
    lookback: int = RENKO_SWING_LOOKBACK,
    swing_type: str = "low",
) -> list[int]:
    """Find swing lows or swing highs in Renko brick data.

    A swing low is a brick whose 'low' is lower than the lows of
    ``swing_window`` bricks on either side.  A swing high uses 'high'.
    Only considers bricks within ``[r_idx - lookback, r_idx]``.

    Parameters
    ----------
    renko_df : pd.DataFrame
        Renko bricks with 'high', 'low', 'direction' columns.
    r_idx : int
        Current position in renko_df.
    lookback : int
        Maximum bricks to look back.
    swing_type : str
        "low" for swing lows, "high" for swing highs.

    Returns
    -------
    list[int]
        Sorted list of brick indices that are swing points.
    """
    col = "low" if swing_type == "low" else "high"
    start = max(0, r_idx - lookback)
    end = r_idx + 1
    n = end - start
    if n < 6:  # need at least 3 bricks on each side of a swing
        return []

    values = renko_df[col].iloc[start:end].values
    swings = []
    # Use a 3-brick window on each side for Renko (less noise than candlestick)
    win = 3
    for i in range(win, n - win):
        is_swing = True
        for j in range(1, win + 1):
            if swing_type == "low":
                if values[i] >= values[i - j] or values[i] >= values[i + j]:
                    is_swing = False
                    break
            else:  # high
                if values[i] <= values[i - j] or values[i] <= values[i + j]:
                    is_swing = False
                    break
        if is_swing and not np.isnan(values[i]):
            swings.append(start + i)
    return swings


def _find_last_two_swings(
    swings: list[int],
    r_idx: int,
    min_sep: int = RENKO_MIN_SWING_SEP,
) -> tuple[int | None, int | None]:
    """From a list of swing indices, return the two most recent that
    are separated by at least ``min_sep`` bricks.

    Returns
    -------
    (older_idx, recent_idx) or (None, None)
    """
    if len(swings) < 2:
        return None, None
    recent = swings[-1]
    older = None
    for s in reversed(swings[:-1]):
        if recent - s >= min_sep:
            older = s
            break
    if older is None:
        return None, None
    return older, recent


def eval_renko_signals(
    renko_daily: pd.DataFrame,
    renko_4h: pd.DataFrame | None,
    r_idx: int,
    renko_rsi: pd.Series,
    h_renko_rsi: pd.Series | None = None,
) -> dict:
    """Evaluate all 8 Pool R (Renko) signals at a single Renko bar.

    Parameters
    ----------
    renko_daily : pd.DataFrame
        Daily Renko brick data with 'close', 'high', 'low', 'direction' columns.
    renko_4h : pd.DataFrame or None
        4H Renko brick data (optional, for R5 lead signal).
    r_idx : int
        Current position in renko_daily.
    renko_rsi : pd.Series
        RSI computed on daily Renko brick closes.
    h_renko_rsi : pd.Series or None
        RSI computed on 4H Renko brick closes.

    Returns
    -------
    dict  mapping signal_id -> (pts: float, fired: bool)
    """
    results: dict[str, tuple[float, bool]] = {}
    if r_idx < 1:
        return _zero_results()

    cur_rsi = float(renko_rsi.iloc[r_idx]) if r_idx < len(renko_rsi) else np.nan
    if np.isnan(cur_rsi):
        return _zero_results()

    # ---------------------------------------------------------------- R1
    # R1: Renko RSI Oversold Recovery — 5 pts, Graded
    # RSI was below 30 at some point in the last 10 Renko bars, now above 30.
    # Graded by how far above 30 the recovery is (30-40 partial, >40 full).
    r1_pts, r1_fired = 0.0, False
    lookback_r1 = min(10, r_idx)
    if lookback_r1 >= 3:
        past_rsi = renko_rsi.iloc[r_idx - lookback_r1: r_idx]
        was_oversold = bool((past_rsi.dropna() < 30.0).any())
        if was_oversold and cur_rsi > 30.0:
            r1_pts = min(5.0, max(0.0, (cur_rsi - 30.0) / 10.0 * 5.0))
            r1_fired = r1_pts > 0
    results["R1"] = (round(r1_pts, 2), r1_fired)

    # ---------------------------------------------------------------- R2
    # R2: Renko RSI Above 50 — 4 pts, Binary
    r2_fired = cur_rsi > 50.0
    results["R2"] = (4.0 if r2_fired else 0.0, r2_fired)

    # ---------------------------------------------------------------- R3
    # R3: Renko Brick Pattern Bullish — 3 pts, Graded
    # Count consecutive bullish (green) bricks at the tail.
    r3_pts, r3_fired = 0.0, False
    if "direction" in renko_daily.columns:
        lookback_r3 = min(10, r_idx + 1)
        directions = renko_daily["direction"].iloc[r_idx - lookback_r3 + 1: r_idx + 1].values
        consecutive = 0
        for d in reversed(directions):
            if d == 1:
                consecutive += 1
            else:
                break
        if consecutive >= 1:
            r3_pts = min(3.0, consecutive * 1.0)  # 1 brick=1pt, 2=2pt, 3+=3pt
            r3_fired = True
    results["R3"] = (round(r3_pts, 2), r3_fired)

    # ---------------------------------------------------------------- R4
    # R4: Renko Trend Alignment — 3 pts, Binary
    # Higher highs AND higher lows in the last 8 Renko bricks.
    r4_pts, r4_fired = 0.0, False
    lookback_r4 = min(8, r_idx + 1)
    if lookback_r4 >= 4:
        window = renko_daily.iloc[r_idx - lookback_r4 + 1: r_idx + 1]
        highs = window["high"].values
        lows = window["low"].values
        # Check that recent high > older high AND recent low > older low
        mid = len(highs) // 2
        if mid > 0:
            recent_high = max(highs[mid:])
            older_high = max(highs[:mid])
            recent_low = min(lows[mid:])
            older_low = min(lows[:mid])
            r4_fired = recent_high > older_high and recent_low > older_low
            r4_pts = 3.0 if r4_fired else 0.0
    results["R4"] = (r4_pts, r4_fired)

    # ---------------------------------------------------------------- R5
    # R5: Renko 4H Lead Signal — 3 pts, Binary
    # 4H Renko RSI turned bullish (>50) before daily Renko did.
    r5_pts, r5_fired = 0.0, False
    if h_renko_rsi is not None and len(h_renko_rsi) > 10:
        # Check if 4H RSI has been > 50 for at least 3 of the last 5 bars
        lookback_h = min(5, len(h_renko_rsi))
        h_window = h_renko_rsi.iloc[-lookback_h:].dropna()
        h_bullish_count = int((h_window > 50.0).sum())
        if h_bullish_count >= 3 and cur_rsi > 45.0:
            r5_pts, r5_fired = 3.0, True
    results["R5"] = (r5_pts, r5_fired)

    # ---------------------------------------------------------------- R6
    # R6: Renko No Bearish Divergence — 2 pts, Binary  [v4.4: swing-based]
    # Uses proper swing high detection instead of crude window-halves.
    # Bearish divergence = price higher high + RSI lower high.
    # R6 fires when NO bearish divergence is detected.
    r6_pts, r6_fired = 0.0, False
    swing_highs = find_renko_swings(renko_daily, r_idx, RENKO_SWING_LOOKBACK, "high")
    older_h, recent_h = _find_last_two_swings(swing_highs, r_idx, RENKO_MIN_SWING_SEP)
    if older_h is not None and recent_h is not None:
        older_price = float(renko_daily["high"].iloc[older_h])
        recent_price = float(renko_daily["high"].iloc[recent_h])
        older_rsi = float(renko_rsi.iloc[older_h]) if older_h < len(renko_rsi) else np.nan
        recent_rsi = float(renko_rsi.iloc[recent_h]) if recent_h < len(renko_rsi) else np.nan
        if not np.isnan(older_rsi) and not np.isnan(recent_rsi):
            price_higher_high = recent_price > older_price
            rsi_lower_high = recent_rsi < older_rsi - RENKO_RSI_DIFF_THRESHOLD
            has_bearish_div = price_higher_high and rsi_lower_high
            r6_fired = not has_bearish_div
            r6_pts = 2.0 if r6_fired else 0.0
    else:
        # Not enough swing data — assume no divergence (conservative: give points)
        r6_fired = True
        r6_pts = 2.0
    results["R6"] = (r6_pts, r6_fired)

    # ---------------------------------------------------------------- R7
    # R7: Renko Bullish Divergence — 4 pts, Binary  [NEW in v4.4]
    # Regular Bullish Divergence: price lower low + RSI higher low.
    # Indicates selling momentum is weakening despite structural breakdown.
    r7_pts, r7_fired = 0.0, False
    swing_lows = find_renko_swings(renko_daily, r_idx, RENKO_SWING_LOOKBACK, "low")
    older_l, recent_l = _find_last_two_swings(swing_lows, r_idx, RENKO_MIN_SWING_SEP)
    if older_l is not None and recent_l is not None:
        older_price = float(renko_daily["low"].iloc[older_l])
        recent_price = float(renko_daily["low"].iloc[recent_l])
        older_rsi = float(renko_rsi.iloc[older_l]) if older_l < len(renko_rsi) else np.nan
        recent_rsi = float(renko_rsi.iloc[recent_l]) if recent_l < len(renko_rsi) else np.nan
        if not np.isnan(older_rsi) and not np.isnan(recent_rsi):
            price_lower_low = recent_price < older_price
            rsi_higher_low = recent_rsi > older_rsi + RENKO_RSI_DIFF_THRESHOLD
            # Floor-effect guard: skip if older RSI < 30 (unreliable)
            if price_lower_low and rsi_higher_low and older_rsi >= 30.0:
                r7_pts, r7_fired = 4.0, True
    results["R7"] = (r7_pts, r7_fired)

    # ---------------------------------------------------------------- R8
    # R8: Renko Hidden Bullish Divergence — 3 pts, Binary  [NEW in v4.4]
    # Hidden Bullish Divergence: price higher low + RSI lower low.
    # Indicates strong trend: pullback is shallower in price but deeper
    # in RSI — trend absorbing selling pressure.
    r8_pts, r8_fired = 0.0, False
    if older_l is not None and recent_l is not None:
        # Reuse the swing lows already found for R7
        older_price = float(renko_daily["low"].iloc[older_l])
        recent_price = float(renko_daily["low"].iloc[recent_l])
        older_rsi = float(renko_rsi.iloc[older_l]) if older_l < len(renko_rsi) else np.nan
        recent_rsi = float(renko_rsi.iloc[recent_l]) if recent_l < len(renko_rsi) else np.nan
        if not np.isnan(older_rsi) and not np.isnan(recent_rsi):
            price_higher_low = recent_price > older_price
            rsi_lower_low = recent_rsi < older_rsi - RENKO_RSI_DIFF_THRESHOLD
            if price_higher_low and rsi_lower_low:
                r8_pts, r8_fired = 3.0, True
    results["R8"] = (r8_pts, r8_fired)

    return results


def _zero_results() -> dict:
    """Return all R-signals as zero (used when data is insufficient)."""
    return {
        "R1": (0.0, False),
        "R2": (0.0, False),
        "R3": (0.0, False),
        "R4": (0.0, False),
        "R5": (0.0, False),
        "R6": (0.0, False),
        "R7": (0.0, False),
        "R8": (0.0, False),
    }


def map_renko_to_daily(renko_df: pd.DataFrame, daily_df: pd.DataFrame,
                        date_col_renko: str = "date",
                        date_col_daily: str = "Date") -> pd.Series:
    """Map each daily bar to the most recent Renko brick index.

    Since Renko bricks don't have a 1:1 mapping to calendar days (multiple
    days can map to the same brick, or a single day can generate multiple
    bricks), this function assigns each daily bar the index of the most
    recent Renko brick whose date is <= the daily bar's date.

    Parameters
    ----------
    renko_df : pd.DataFrame
        Renko bricks with a date column.
    daily_df : pd.DataFrame
        Daily OHLC data with a date column.
    date_col_renko : str
        Name of the date column in renko_df.
    date_col_daily : str
        Name of the date column in daily_df.

    Returns
    -------
    pd.Series
        Integer series aligned to daily_df index, giving the Renko brick
        index for each daily bar. -1 if no matching brick.
    """
    # Parse dates
    renko_dates = pd.to_datetime(renko_df[date_col_renko], errors="coerce")
    daily_dates = pd.to_datetime(daily_df[date_col_daily], errors="coerce")

    mapping = pd.Series(-1, index=daily_df.index)
    r_pos = 0
    for d_pos in range(len(daily_df)):
        d_date = daily_dates.iloc[d_pos]
        if pd.isna(d_date):
            continue
        # Advance r_pos to the last brick with date <= daily date
        while r_pos < len(renko_dates) - 1:
            if pd.notna(renko_dates.iloc[r_pos + 1]) and renko_dates.iloc[r_pos + 1] <= d_date:
                r_pos += 1
            else:
                break
        if r_pos < len(renko_dates) and pd.notna(renko_dates.iloc[r_pos]):
            if renko_dates.iloc[r_pos] <= d_date:
                mapping.iloc[d_pos] = r_pos
    return mapping
