"""Apollo Core — Entry Gates Module (v4.7)

Hard filters evaluated at ENTRY time, independent of the additive score.
If ANY gate fails, the entry is blocked regardless of score (same spirit
as the Renko Hard Gate — but unlike Renko, these gates are actually wired).

Gates:
    G1: PE Sanity          — block if trailing PE <= 0 or PE > PE_MAX.
                            Requires a per-symbol fundamental profile
                            (etmoney); skipped when profile is absent.
    G2: Liquidity Floor    — block if 20-day avg traded value
                            (close * volume) < MIN_AVG_TRADED_VALUE.
                            Computed from OHLCV.
    G3: 52W-Low Proximity  — block if close > MAX_52W_LOW_DIST above the
                            trailing 52-week low (stock must still be near
                            its low — trough-recovery premise).
    G4: 52W-High Distance  — block if the trailing 52-week high is not at
                            least MIN_52W_HIGH_DIST_MULT x close (stock must
                            still be meaningfully below its 52W high —
                            beaten-down premise).

The gate series (G2/G3/G4) are pure functions of the daily OHLCV frame
and are pre-computed once per run, then indexed by bar. G1 is a static
per-symbol check from the fundamental profile.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from apollo_core.constants import (
    PE_MAX,
    MIN_AVG_TRADED_VALUE,
    MAX_52W_LOW_DIST,
    MIN_52W_HIGH_DIST_MULT,
)

GATE_WEEK_LOOKBACK = 252  # trailing 52-week window for low/high


def compute_gate_frame(df_d: pd.DataFrame) -> pd.DataFrame:
    """Pre-compute the per-bar OHLCV-derived gate inputs.

    Returns a DataFrame indexed like ``df_d`` with columns:
        avg_traded_value_20, low_52w, high_52w
    """
    close = df_d["close"]
    volume = df_d["volume"] if "volume" in df_d.columns else pd.Series(np.nan, index=df_d.index)
    traded_value = close * volume

    frame = pd.DataFrame(index=df_d.index)
    frame["avg_traded_value_20"] = traded_value.rolling(20, min_periods=10).mean()
    frame["low_52w"] = df_d["low"].rolling(GATE_WEEK_LOOKBACK, min_periods=60).min()
    frame["high_52w"] = df_d["high"].rolling(GATE_WEEK_LOOKBACK, min_periods=60).max()
    return frame


def evaluate_gate_row(
    row: pd.Series,
    pe: float | None = None,
) -> tuple[bool, list[str]]:
    """Evaluate all entry gates for a single bar.

    Parameters
    ----------
    row : pd.Series
        A row from :func:`compute_gate_frame`.
    pe : float or None
        Trailing PE from the fundamental profile. ``None`` skips G1.

    Returns
    -------
    (passed, failed) — ``passed`` is True only when every evaluated gate
    passes; ``failed`` lists the human-readable reasons of the gates that
    blocked entry.
    """
    failed: list[str] = []

    # G1: PE Sanity
    if pe is not None and not np.isnan(pe):
        if pe <= 0:
            failed.append(f"G1 PE<=0 (PE={pe:.1f})")
        elif pe > PE_MAX:
            failed.append(f"G1 PE>{PE_MAX:.0f} (PE={pe:.1f})")

    # G2: Liquidity Floor
    av = row.get("avg_traded_value_20", np.nan)
    if not np.isnan(av) and av < MIN_AVG_TRADED_VALUE:
        failed.append(
            f"G2 Low Liquidity (avg ₹{av/1e7:.0f} Cr/day < ₹{MIN_AVG_TRADED_VALUE/1e7:.0f} Cr)"
        )

    # G3: 52W-Low Proximity
    close = row.get("close", np.nan)
    low_52w = row.get("low_52w", np.nan)
    if not np.isnan(close) and not np.isnan(low_52w) and low_52w > 0:
        dist = (close - low_52w) / low_52w
        if dist > MAX_52W_LOW_DIST:
            failed.append(f"G3 Far from 52W Low (+{dist*100:.0f}% > +{MAX_52W_LOW_DIST*100:.0f}%)")

    # G4: 52W-High Distance (beaten-down premise)
    high_52w = row.get("high_52w", np.nan)
    if not np.isnan(close) and not np.isnan(high_52w):
        if high_52w < MIN_52W_HIGH_DIST_MULT * close:
            failed.append(
                f"G4 Near 52W High (52W high {high_52w:.1f} < {MIN_52W_HIGH_DIST_MULT:.2f}x close {close:.1f})"
            )

    return (len(failed) == 0, failed)
