# Apollo Engine — Changelog

This changelog tracks BOTH engines:
- **Apollo Backtest** (`Apollo_Backtest_*.zip` or `Apollo_Live_*.zip`) — Streamlit dashboard, historical analysis
- **Apollo Live** (`Apollo_Live_*.zip`) — Live signal monitor, advisory alerts, state persistence

---

## v4.7 — Equity Analytics (Pool E) & Entry Gates

**Date**: 2026-08-01
**Purpose**: Incorporate the user's Google Sheet screening analytics into the engine itself. Adds 5 new additive Pool E signals (max 21 pts) and 4 hard entry gates that block entry regardless of score — mirroring the sheet's own scoring columns so the engine only fires on stocks that pass the user's screening criteria.

### What's new
- **Pool E — Equity Analytics (21 pts, additive)**:
  - E1: Near 52W Low (5 pts) — price proximity to trailing 52-week low
  - E2: Stochastic Oversold Turn (5 pts) — %K crosses above %D from oversold
  - E3: Relative Volume Surge (4 pts) — volume vs 20-day average
  - E4: VPT Accumulation (4 pts) — rising Volume Price Trend
  - E5: 50-SMA Recovery Zone (3 pts) — price 0-10% above 50-DMA
- **Entry Gates (hard filters, block entry regardless of score)**:
  - G1: PE Sanity (from `etmoney_stocks_list.json`, skipped if absent)
  - G2: Liquidity Floor (20-day avg traded value)
  - G3: 52W-Low Proximity (close within +75% of trailing 52W low)
  - G4: 52W-High Distance (must be >10% below trailing 52W high)
- Gate-blocked bars emit `GATE-BLOCKED` events (backtest) and `GATE-BLOCKED` alerts (live), so blocked entries are visible — not silently skipped.
- New modules: `apollo_core/gates.py`, `apollo_core/fundamentals.py`.
- New indicators: Stochastic %K/%D, VPT, SMA50/SMA20 (`apollo_core/indicators.py`).
- `tests/preflight.py` pre-flight suite created (was missing from previous zips).

### Fixed
- The sheet's **Relative Volume** column is still a duplicate of `volume` — flagged to user; the engine's E3 computes the true volume/20-day-avg ratio internally, so the engine is not dependent on the sheet formula.

---

## v4.6 — Chartink Pipeline (Automated Watchlist Curation)

**Date**: 2026-07-31
**Purpose**: Fully automated pipeline that fetches Chartink RSI Dashboard + NIFTY 500 Gainers data, scores stocks against Apollo's RSI recovery profile, and updates `my_watchlist.json` with curated candidates. Zero user intervention after one-time setup.

### What's new

#### 1. `chartink_pipeline/` — New package (4 files)

- **`auth.py`** — One-time Chartink login via Playwright browser. Saves session cookies to `chartink_state.json`. Re-run every 30-60 days to refresh.
- **`fetcher.py`** — Pure HTTP client for Chartink's screener API. Uses saved session (no browser needed at runtime). Fetches 6 RSI dashboard panels + 6 NIFTY 500 Gainers panels. Built-in retry logic + CSRF handling.
- **`watchlist_generator.py`** — Scoring bridge between Chartink data and Apollo's entry profile. Computes 0-100 Recovery Score (mirrors Pool A + Pool C RSI logic), cross-references momentum data, applies boost/penalty adjustments, generates ranked watchlist.
- **`run_pipeline.py`** — Main pipeline runner. Orchestrates: fetch → score → merge into `my_watchlist.json`. Supports `--dry-run`, `--fetch-only`, `--threshold`, `--max` flags.
- **`__main__.py`** — Allows `python -m chartink_pipeline` invocation.

#### 2. VPS Deployment (`deploy/` — 5 files)

- **`run_chartink_pipeline.sh`** — Linux shell runner with logging.
- **`run_chartink_pipeline.bat`** — Windows batch runner.
- **`chartink-cron.service`** + **`chartink-cron.timer`** — systemd unit files for daily 3:35 PM IST execution.
- **`setup_vps.sh`** — One-time VPS setup (installs deps, Playwright Chromium, configures systemd).
- **`crontab_example.txt`** — Cron examples for non-systemd systems.

#### 3. Pipeline flow

```
Chartink Login (once) → Session saved
        ↓
3:35 PM IST (daily cron)
        ↓
Chartink API (12 scans: 6 RSI + 6 Gainers)
        ↓
RSI Recovery Score (0-100, mirrors Apollo Pool A+C)
        ↓
Momentum Cross-Reference (NIFTY 500 Gainers)
        ↓
Boost/Penalty Adjustments
        ↓
Ranked Watchlist (top N, deduplicated)
        ↓
Merge into my_watchlist.json (backup created)
        ↓
Apollo Live Engine picks up updated watchlist
```

#### 4. No changes to existing scoring/live engine code

The pipeline is fully additive — it only READS from and WRITES to `my_watchlist.json`. No modifications to `scoring.py`, `signal_monitor.py`, `multi_monitor.py`, or any existing module. The live engine's `watchlist.py` already handles reloading `my_watchlist.json` dynamically.

### Usage

```bash
# One-time setup
pip install -r requirements.txt
playwright install chromium
python -m chartink_pipeline.auth          # Log into Chartink

# Daily run (or set up cron — see deploy/)
python -m chartink_pipeline.run_pipeline
python -m chartink_pipeline.run_pipeline --dry-run  # Preview only
```

### Dependencies added

- `requests>=2.28.0` (HTTP client for Chartink API)
- `playwright>=1.40.0` (browser automation for one-time auth only)

---

## v4.5 — Ranking Enrichment (CMP, Period Low, Recovery%)

**Date**: 2026-07-30
**Purpose**: Add three price-context columns to the Stock Ranking table in the Results tab, giving immediate visibility into each stock's current price, its lowest price during the backtesting period, and how much it has recovered from that low.

### What's new

#### 1. Stock Ranking Table — 3 New Columns

- **CMP** (between Symbol and Bucket): Last recorded close price from the backtesting CSV data, formatted as ₹XXXX.XX.
- **Period Low** (after Win Rate%): Lowest recorded low price during the entire backtesting date range (start_date to end_date).
- **Recovery from Low%** (before Cum P&L%): Percentage recovery from the period low to CMP — `((CMP - Period Low) / Period Low) * 100`. Shows how much of the recovery the backtesting period captures.

#### 2. Files changed

- `backtest_engine/backtest.py` — Added `cmp`, `period_low`, `recovery_pct` to the per-stock result dict. CMP from `daily_df['close'].iloc[-1]`, Period Low from `df_d['low'].min()` within the backtesting date range.
- `backtest_engine/app.py` — Ranking table now has 19 columns (was 16). Column configs added for CMP, Period Low, Recovery from Low%.
- `backtest_engine/report_generator.py` — XLSX Summary sheet ranking table updated with the same 3 columns (CMP, Period Low, Recovery from Low%).

#### 3. No scoring engine changes

All `apollo_core/` modules are version-bumped but have zero logic changes. The 21-signal system, divergence signals (D1/R7/R8), and Renko Hard Gate remain identical to v4.4.

---

## v4.4 — Apollo Backtest: Divergence Scoring

**Date**: 2026-07-30
**Purpose**: Add RSI divergence signals on both candlestick and Renko charts, based on empirical analysis of 4 stocks (APOLLO, CEMPRO, JYOTICNC, KAYNES) with data-driven lookback optimization.

### What's new

#### 1. `apollo_core/scoring.py` — D1: Hidden Bullish Divergence (Daily Candlestick)

New signal D1 (5 pts, Binary) in Pool BD. Detects hidden bullish divergence on daily candlestick: price higher low + RSI lower low across two swing lows within a 45-bar lookback. Backtested across 4 stocks at 5 lookback periods (30/45/60/75/90): 45-bar was optimal inflection point (24 clean signals, 13T/11F = 54% accuracy). Includes floor-effect guard (skips when older swing RSI < 30, which showed only 33% accuracy).

#### 2. `apollo_core/renko.py` — R7: Renko Bullish Divergence

New signal R7 (4 pts, Binary) in Pool R. Detects regular bullish divergence on Renko bricks: price lower low + RSI higher low. Uses proper swing-based detection via new `find_renko_swings()` helper. Includes floor-effect guard (older RSI >= 30 required).

#### 3. `apollo_core/renko.py` — R8: Renko Hidden Bullish Divergence

New signal R8 (3 pts, Binary) in Pool R. Detects hidden bullish divergence on Renko bricks: price higher low + RSI lower low. This is the trend-continuation signal — shallow pullback in price but deep RSI dip indicates the trend is absorbing selling pressure.

#### 4. `apollo_core/renko.py` — R6 upgraded to swing-based bearish divergence

R6 previously used crude window-halves (split 15-brick window in half and compare min lows). Now uses proper `find_renko_swings()` for swing high detection. Detects actual bearish divergence: price higher high + RSI lower high. More accurate and produces fewer false positives.

#### 5. Pool max updates

- Pool R: 20 → 27 pts (added R7=4, R8=3)
- Pool BD: 13 → 18 pts (added D1=5)
- Total engine max: 148 → 170 pts (25 signals total)

### CyientDLM verification

- Trades: 18 (down from 22 in v4.3 — D1/R6 changes affect entry filtering)
- The D1 signal adds 5 pts to BD pool when hidden bullish divergence is detected, contributing to higher scores on qualifying setups.

---

## Apollo Backtest v4.3 — Renko Hard Gate (Option B)

**Date**: 2026-07-30
**Purpose**: Data-driven selection of Renko gating approach. Evaluated 5 variants (Baseline, Soft Gate, Option A, Option B, Option C) on CyientDLM data. Option B (Hard Gate R>=5) won decisively: +34.95% cum P&L vs +30.05% baseline, PF 1.57 vs 1.34, DD -43% vs -58%. Implemented as a mandatory entry filter in the scoring engine.

### What's new

#### 1. `apollo_core/constants.py` — RENKO_HARD_GATE threshold

New constant `RENKO_HARD_GATE = 5`. When > 0, acts as a mandatory minimum bullish Renko R-points requirement for BUY classification. Set to 0 to disable (pure score-based entry, backward-compatible).

#### 2. `apollo_core/scoring.py` — classify_score() with Renko Hard Gate

`classify_score()` now accepts an optional `r_points` parameter (float or None). When provided and `RENKO_HARD_GATE > 0`, any score that would normally classify as BUY (STANDARD/FULL ENTRY/FULL STRONG) is downgraded to `"RENKO GATED"` if `r_points < RENKO_HARD_GATE`. Passing `r_points=None` (default) skips the gate entirely, preserving backward compatibility with all existing callers.

New action label: `"RENKO GATED"` — score qualifies as BUY but Renko trend structure confirmation is insufficient.

#### 3. Version bump across all engine files

All core module headers, app.py title line, and pre-flight test suite updated from v3.5 to v4.3.

### CyientDLM verification (with engine-native exit scoring)

| Metric | Baseline (no Renko) | v4.3 Option B |
|--------|---------------------|----------------|
| Trades | 32 | 22 |
| Win Rate | 37.5% | 45.5% |
| Cumulative P&L | +30.05% | +43.67% |
| Max Drawdown | -57.91% | -35.00% |
| Profit Factor | 1.34 | 1.82 |
| SL Hits | 15/32 (47%) | 10/22 (45%) |

### Why Soft Gate and Option C were rejected

- **Soft Gate** (add R-points, no filter): Added 3 extra false entries, cum P&L dropped from +30% to +6.87%
- **Option A** (R=0 requires score>=80): Replaced good entries with different bad ones, cum P&L +2.40%
- **Option C** (negative bearish R-signals): Identical to Soft Gate — bearish signals fired on only 8.3% of bars and never at entry points

---

## Apollo Live v1.4 — Headless operational release (Phase 2 Step 4)

**Date**: 2026-07-27
**Purpose**: Pivot from UI polish to VPS/cloud-ready operational engine. User asked: "make sure that functionality that we have build in the Apollo Live engine works correctly and will be able to deal with live data once presented." v1.4 delivers the backend operational layer — alert delivery (file log + Telegram), daily report generation (MD + CSV + Telegram push), a headless runner with no Streamlit dep (for systemd/Docker deployment), and an abstract LiveFeed protocol with a KiteLiveFeed stub for future Zerodha Kite Connect integration. Includes a critical bugfix to MultiStockMonitor (resume=False crash) that v1.3 shipped broken.

### What's new

#### 1. `live_engine/alert_manager.py` — new module (file log + Telegram)

Multi-channel alert delivery. Plugs into `MultiStockMonitor`'s `alert_callback` to fan out ENTRY/EXIT/COOLDOWN alerts to:

- **File log** (`reports/alerts.log`) — append-only JSONL, always on, zero config. Baseline channel; if everything else fails, alerts are still on disk for the daily report.
- **Telegram bot** — instant push to a Telegram chat. Optional, configured via environment variables `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID`. If either is missing, Telegram is silently skipped (file log still works).

Design highlights:
- `AlertManager` class is the single orchestrator. Each channel is a `_Backend` subclass with a `send(alert, symbol)` method. Adding a new channel (Email, Discord) is one new subclass.
- **Fail-soft**: any backend exception is logged but never propagates. A broken Telegram token never crashes the monitor loop.
- **Async dispatch**: Telegram sends are queued + dispatched by a background worker thread so the monitor's main loop never blocks on network I/O. Queue is drained on `shutdown()`.
- `make_callback(am)` factory builds a callback matching `MultiStockMonitor`'s `(alert, symbol)` signature, with optional stdout mirroring for loud alert types (ENTRY/EXIT/COOLDOWN).
- HOLD/WAIT/STARTUP alerts are file-only by default (configurable via `push_types`).

#### 2. `live_engine/daily_report.py` — new module (MD + CSV + Telegram push)

Generates a per-day report with:

- **All alerts fired on that date** — pulled from SQLite `alerts` table. Includes ENTRY, EXIT, HOLD, COOLDOWN (STARTUP filtered from MD summary, kept in CSV).
- **Top-N watchlist ranking by current score** — re-runs `BarReplay` for each watchlist stock (fast, no alerts emitted) to compute current composite score. Sorted descending. Default top 10.
- **Open positions table** — symbols currently in-trade with entry price/date/peak close/pending-exit flag.

Output formats (per day `YYYY-MM-DD`):
- `reports/YYYY-MM-DD.md` — human-readable markdown with sections for Alerts Fired, Open Positions, Top-N Watchlist.
- `reports/YYYY-MM-DD_alerts.csv` — flat alerts table (timestamp, symbol, alert_type, message, payload_json).
- `reports/YYYY-MM-DD_rankings.csv` — flat rankings table (rank, symbol, name, sector, score, last_date, bucket, is_ipo, n_bars).

If Telegram is configured, the MD summary is also pushed to the chat at generation time (truncated to 3900 chars to respect Telegram's 4096-char message limit).

CLI: `python -m live_engine.daily_report --db live_state.db --watchlist my_watchlist.json --date 2026-07-24`

#### 3. `live_engine/run_headless.py` — new module (VPS-friendly entrypoint)

Runs `MultiStockMonitor` (or single-stock `SignalMonitor`) without Streamlit. Suitable for VPS / cloud deployment via systemd, Docker, or plain `nohup`. Features:

- **Signal handling**: catches SIGINT (Ctrl-C) and SIGTERM (systemd stop), calls `monitor.stop()` and `alert_manager.shutdown()`, exits 0.
- **AlertManager wiring**: automatically builds + starts + shuts down an `AlertManager` (file log + optional Telegram). Pass `--no-telegram` for file-only mode.
- **All v1.3 monitor options**: `--watchlist`, `--pace-seconds`, `--exit-mode`, `--no-resume`, `--auto-confirm`, `--quiet`, etc.
- **`--once` flag**: shortcut for `--pace-seconds 0` (process all bars then exit). Useful for batch scoring / daily report seeding.
- **Startup banner**: prints config (mode, symbols, date range, exit mode, pace, DB path, Telegram status, file log path) so you can verify at a glance.
- **Run summary**: on completion, prints aggregate stats (ticks, bars, entries, exits, holds, waits, cooldowns).

Usage examples:
```
# Multi-stock, paced at 2 sec/bar, alerts to file + Telegram
python -m live_engine.run_headless --watchlist my_watchlist.json --pace-seconds 2.0

# Single-stock, quiet, file-only
python -m live_engine.run_headless --symbol CYIENTDLM --quiet --no-telegram

# systemd-friendly (process all bars then exit, for cron-style scheduling)
python -m live_engine.run_headless --watchlist my_watchlist.json --once
```

#### 4. `live_engine/live_feed.py` — new module (abstract LiveFeed + Kite stub)

Defines the abstract `LiveFeed` protocol that the engine consumes bars from. Today there's one concrete implementation:

- `BarReplayFeed` — wraps the existing `BarReplay` CSV iterator. Production-safe, what the engine uses today.

And one stub for the future:

- `KiteLiveFeed` — placeholder for Zerodha Kite Connect integration. Raises `NotImplementedError` on every method. This is intentional — v1.4's job is to define the *interface*, not ship a live broker integration. When the user is ready to go live (Step 5+), this class gets filled in with real websocket + REST calls.

Why an abstraction? The current `MultiStockMonitor` calls `monitor.replay.replay()` directly, coupling the monitor to CSV-backed replay. By introducing a `LiveFeed` protocol, the monitor becomes data-source-agnostic. When Kite is implemented, the user passes `feed=KiteLiveFeed(...)` instead of letting the monitor build a `BarReplay` internally. No monitor code changes required.

Uses `typing.Protocol` (structural subtyping) — any class with the right method signatures is a `LiveFeed`, no inheritance required. Useful when wrapping third-party libraries whose classes we can't subclass.

`make_feed(source, symbol, ...)` factory: `"csv"` → `BarReplayFeed`, `"kite"` → `KiteLiveFeed` (raises).

#### 5. `live_engine/multi_monitor.py` — critical bugfix

**v1.3 bug** (shipped broken): `MultiStockMonitor._run_loop()` crashed with `AttributeError: 'NoneType' object has no attribute 'in_trade'` whenever `resume=False`. The line `monitor._position = type(monitor._position)()` was intended to create a fresh `Position`, but `_position` is `None` at that point (SignalMonitor's `__init__` sets it to None until `_load_state()` runs), so `type(None)()` returned `None`, leaving `_position` as None. The next line (`monitor._position.in_trade`) then crashed.

**v1.4 fix**: replaced `type(monitor._position)()` with an explicit `Position()` (imported from `apollo_core.types`). This matches what `SignalMonitor.run()` does for the single-stock path (line 614 of signal_monitor.py).

Impact: `--no-resume` flag was unusable in v1.3 multi-stock mode. Now works correctly. Caught by the v1.4 audit (test #26 in preflight).

#### 6. `live_engine/cli.py` — `--headless` flag

New `--headless` flag routes to `run_headless.main()` with all relevant args forwarded. Also added `--no-telegram` and `--reports-dir` flags (forwarded to headless). Lets users use the same CLI for both UI mode (default) and headless mode (VPS).

```
# Old (UI mode — opens Streamlit dashboard)
python -m live_engine --symbol CYIENTDLM

# New (headless mode — VPS-friendly, no Streamlit)
python -m live_engine --headless --watchlist my_watchlist.json
```

#### 7. `tests/preflight_live.py` — 6 new tests (22-27)

- **Test 22**: AlertManager writes JSONL to file log (2 alerts, parseable JSON).
- **Test 23**: AlertManager fail-soft on malformed alerts (non-serializable payload doesn't raise).
- **Test 24**: DailyReport generates MD + 2 CSVs with expected content (sections, seeded alert, rankings).
- **Test 25**: LiveFeed protocol — BarReplayFeed works, KiteLiveFeed raises NotImplementedError, bad source raises ValueError.
- **Test 26**: v1.4 bugfix verification — MultiStockMonitor(resume=False) no longer crashes.
- **Test 27**: run_headless argparse parses multi/single/once/no-telegram flags.

Total: 27 tests (was 21 in v1.3). All must pass for the zip to be shippable.

### How to use v1.4

#### Run the engine headless (no UI)

```bash
# Multi-stock, file log + Telegram (if env vars set)
python -m live_engine.run_headless --watchlist my_watchlist.json --pace-seconds 2.0

# Or via the unified CLI:
python -m live_engine --headless --watchlist my_watchlist.json
```

#### Configure Telegram (optional)

1. Create a bot via [@BotFather](https://t.me/BotFather) — get the bot token.
2. Get your chat ID via [@userinfobot](https://t.me/userinfobot).
3. Set env vars:
   ```bash
   export TELEGRAM_BOT_TOKEN="123456:ABC-DEF..."
   export TELEGRAM_CHAT_ID="987654321"
   ```
4. Run the engine. ENTRY/EXIT/COOLDOWN alerts now push to your Telegram chat.

#### Generate the daily report

```bash
# Today's report (pushes MD to Telegram if configured)
python -m live_engine.daily_report --db live_state.db --watchlist my_watchlist.json

# Specific date, no Telegram push
python -m live_engine.daily_report --db live_state.db --date 2026-07-24 --no-telegram
```

Output files land in `reports/`:
- `reports/2026-07-24.md` — human-readable
- `reports/2026-07-24_alerts.csv` — flat alerts table
- `reports/2026-07-24_rankings.csv` — flat rankings table

#### Deploy on VPS (systemd)

```bash
# /etc/systemd/system/apollo-live.service
[Unit]
Description=Apollo Live Engine
After=network.target

[Service]
Type=simple
User=apollo
WorkingDirectory=/opt/apollo-live
Environment=TELEGRAM_BOT_TOKEN=...
Environment=TELEGRAM_CHAT_ID=...
ExecStart=/usr/bin/python -m live_engine.run_headless --watchlist my_watchlist.json --pace-seconds 2.0
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now apollo-live
sudo journalctl -u apollo-live -f  # tail logs
```

### What's NOT in v1.4 (deferred to v1.5+)

- **Actual Zerodha Kite Connect integration** — only the interface is defined. Implementation is a future release (Step 5+).
- **Email/SMTP alert delivery** — only file + Telegram channels shipped. Easy to add (new `_Backend` subclass).
- **Webhook alert delivery** — same as above.
- **Intraday timeframe support** — current engine is daily-bar only. Live Kite ticker integration will bring intraday.
- **Native desktop app** — explicitly deferred per user direction. The dashboard stays as Streamlit for now.

### Files changed

| File | Change |
|------|--------|
| `live_engine/__init__.py` | Version bump 1.3 → 1.4. Updated module list docstring. |
| `live_engine/alert_manager.py` | **NEW** (440 lines). AlertManager + FileLogBackend + TelegramBackend + make_callback. |
| `live_engine/daily_report.py` | **NEW** (380 lines). generate_report() + CLI + Telegram push. |
| `live_engine/run_headless.py` | **NEW** (310 lines). Headless runner with signal handling. |
| `live_engine/live_feed.py` | **NEW** (260 lines). LiveFeed protocol + BarReplayFeed + KiteLiveFeed stub + make_feed factory. |
| `live_engine/multi_monitor.py` | Bugfix: `type(monitor._position)()` → `Position()`. Added `from apollo_core.types import Position`. |
| `live_engine/cli.py` | Added `--headless`, `--no-telegram`, `--reports-dir` flags. Forwarding logic to `run_headless.main()`. |
| `tests/preflight_live.py` | Version bump v1.3 → v1.4. Added 6 new tests (22-27). Updated required files + import list. |

---

## Apollo Live v1.3 — Multi-stock watchlist mode + paced replay + chart zoom (Phase 2 Step 3)

**Date**: 2026-07-27
**Purpose**: First true "live scanner" release. v1.2 fixed the missing-CSV bug but still felt dead — the monitor finished all bars in seconds and exited, so users saw no gradual alert stream. v1.3 makes the dashboard feel like a real market scanner: monitor all watchlist stocks in parallel, pace the replay so alerts stream in over minutes, and add proper chart zoom/pan/range-slider interactions. Built as a pilot per user request — further refinements to come.

### What's new

#### 1. `live_engine/watchlist.py` — new module

Loads the watchlist from `my_watchlist.json` (515 stocks in Yahoo Finance `XXX.NS` format) and filters to only stocks whose CSV is in `data/`. This is what populates the multi-stock dashboard's monitored universe. Functions:

- `load_watchlist(path)` — load JSON, normalize entries, strip `.NS` suffix.
- `list_available_csvs(data_dir)` — scan for `*.csv`, skip `*_D` / `*_4H` / `*_W` sidecars.
- `load_available(watchlist_path, data_dir)` — intersection of watchlist ∩ CSVs. Known test stocks (APOLLO, CYIENTDLM, SYRMA, JYOTICNC, KAYNES) come first in declared order, then extras alphabetically.
- `list_available_symbols(...)` — convenience wrapper returning just the symbol list.
- `DEFAULT_WATCHLIST_PATH` — `<project_root>/my_watchlist.json`.

#### 2. `live_engine/multi_monitor.py` — new module

`MultiStockMonitor` class — runs N stocks in parallel (round-robin) with configurable pacing. Wraps N `SignalMonitor` instances (one per stock). Per tick:

1. For each stock with bars remaining: pull the next `ReplayBar`, call `monitor.process_bar(bar)` — emits alert to StateStore + alert_callback.
2. Sleep `pace_seconds` (in 0.1s increments so `stop()` can interrupt quickly).
3. Repeat until all stocks exhausted OR `stop()` called (thread-safe via `threading.Event`).

Each stock's `Position` + `last_processed_date` is persisted to the shared SQLite DB (keyed by symbol). So you can stop anytime, restart, and each stock resumes from where it left off. Constructor accepts the same exit config as single-stock mode (applies uniformly to all stocks).

Returns a summary dict with per-stock stats + aggregate counts (`n_symbols`, `n_ticks`, `total_entries`, `total_exits`, etc.).

#### 3. `live_engine/state_store.py` — two new methods

- `list_monitored_symbols()` — returns all symbols with state rows in `monitor_state` (used by the dashboard to know which stocks have been monitored).
- `list_alerts_all_symbols(limit=50, alert_types=None)` — returns most recent alerts across ALL symbols, newest first. Optional `alert_types` filter (e.g., only ENTRY/EXIT/COOLDOWN, skip HOLD/WAIT spam).

#### 4. `live_engine/cli.py` — multi-stock mode + pace flag

- `--symbol` is no longer required (was `required=True` in v1.2, now `default=None`).
- New `--watchlist PATH` flag — when given, runs `MultiStockMonitor` on all watchlist stocks with CSVs in `--data-dir`.
- New `--pace-seconds FLOAT` flag (default 2.0) — seconds to sleep between bars in multi-stock mode. `0` = instant.
- Backward compatible: when `--watchlist` is not given, runs single-stock `SignalMonitor` exactly as v1.2.
- Alert callback extended to support `(alert, symbol)` signature in multi mode (prints symbol alongside timestamp/type/message).

#### 5. `live_engine/dashboard.py` — grid view + chart zoom + pace slider

**Sidebar**:
- New **Monitor mode** radio toggle at top: "Single-stock" (v1.2 behavior) vs. "Multi-stock (watchlist)" (v1.3).
- In multi mode: shows watchlist path input, available symbols (filtered), **Replay pace slider** (0–30 seconds per bar, default 2.0), and "Refresh watchlist" button.
- Single-stock mode unchanged from v1.2.
- The sidebar code is split into three functions for clarity: `_render_sidebar()` (dispatcher), `_render_sidebar_multi()` (v1.3 path), `_render_sidebar_single_legacy()` (v1.2 path).

**Chart zoom (both modes)**:
- Plotly `fig.update_layout(dragmode="zoom")` — default drag = zoom (instead of pan).
- `fig.update_xaxes(rangeslider=dict(visible=True, thickness=0.08))` — range slider below chart for quick date-range selection.
- `rangeselector` buttons: 1m / 3m / 6m / 1y / All.
- `st.plotly_chart(..., config={"scrollZoom": True, "displayModeBar": True, ...})` — scroll wheel zooms x-axis, mode bar always visible, lasso/select tools removed (not useful for time-series).

**Multi-stock grid view** (`_render_grid_view`):
- **Combined Alerts Feed** at top — latest 30 alerts across ALL stocks in a single table (Timestamp, Symbol, Type, Message). Updates every 2 seconds.
- **Stock Grid** — 3-column responsive grid. Each cell shows:
  - Symbol name + status badge (FLAT / IN TRADE / PENDING EXIT / COOLDOWN)
  - Mini Plotly chart (220px tall) with score line + ENTRY (green ▲) / EXIT (red ▼) markers + threshold lines
  - Latest score + date caption
  - "🔎 Expand {symbol}" button to switch the detail view below
- **Detail View** below the grid — shows the selected stock's full chart (with zoom + range slider) + pending exit panel + alerts table + position details. Reuses the v1.2 single-stock renderers.
- Auto-refresh interval drops to 2s in multi mode (vs 5s in single mode) so the alerts feed feels live.

**Subprocess launcher** (`_start_monitor_subprocess`):
- New optional params: `multi_stock`, `watchlist_path`, `pace_seconds`.
- When `multi_stock=True`, the CLI command includes `--watchlist PATH --pace-seconds N` instead of `--symbol X`.
- Detached as before (`CREATE_NEW_PROCESS_GROUP` on Windows / `start_new_session` on POSIX).

#### 6. Version bumps

- `live_engine/__init__.py`: `__version__ = "1.3"` (was "1.2")
- `live_engine/dashboard.py` docstring: `Phase 2 Step 3 (v1.3)`
- `live_engine/run_live.py` docstring: `Phase 2 Step 3 (v1.3)`
- `live_engine/cli.py` banner: `Apollo Live Engine v1.3` (both single + multi modes)
- `tests/preflight_live.py`: `CURRENT_VERSION = "v1.3"`, `CURRENT_VERSION_DOTTED = "1.3"`

### Compatibility

- **No breaking changes to single-stock mode.** Default sidebar selection is "Single-stock" — existing v1.2 users see the same UI they had before. Multi-stock mode is opt-in via the radio toggle.
- **State DB schema unchanged.** Existing `live_state.db` files from v1.0 / v1.1 / v1.2 continue to work. New methods (`list_monitored_symbols`, `list_alerts_all_symbols`) work on existing schemas.
- **Watchlist file is unchanged.** `my_watchlist.json` continues to use Yahoo Finance `XXX.NS` format; the loader strips `.NS` internally.
- **CSV requirements unchanged.** Drop `SYMBOL.csv` (e.g., `SYRMA.csv`) into `data/` and click Refresh — it appears in the multi-stock grid automatically (must also be in `my_watchlist.json`).

### How to test (pilot flow)

1. Extract the zip to a clean folder.
2. Run `python live_engine/run_live.py` — dashboard opens in single-stock mode (CYIENTDLM only, since that's the only CSV shipped).
3. In the sidebar, switch **Monitor mode** to "Multi-stock (watchlist)".
4. Sidebar shows "1 stock(s) available: CYIENTDLM" — only CYIENTDLM is in the watchlist AND has a CSV on disk.
5. Set **Replay pace** to 2 seconds per bar (default).
6. Click **▶ Start Monitor** — multi-stock subprocess starts. Watch the **Combined Alerts Feed** populate as bars stream in (2s per bar = ~8 min for a year of CYIENTDLM data).
7. The **Stock Grid** shows one cell for CYIENTDLM with live status badge + mini chart.
8. Click **🔎 Expand CYIENTDLM** — detail view opens below with full chart (try scroll-wheel zoom + range slider).
9. To add more stocks: drop their CSVs into `data/`, click **↻ Refresh watchlist** in the sidebar, then restart the monitor.

### Known limitations (pilot)

- **One CSV shipped.** Only CYIENTDLM is in `data/` by default. To monitor other watchlist stocks, the user must source their CSVs separately. (Future: auto-download from broker or NSE EOD source.)
- **Pace is per-bar, not per-tick.** With 1 stock, 1 bar = 1 tick. With 5 stocks, 1 tick processes 1 bar from each stock = 5 bars per `pace_seconds` interval. (Future: per-stock pacing for true parallel feel.)
- **No alert filtering in combined feed.** All alert types (ENTRY/EXIT/COOLDOWN/STARTUP) are shown. (Future: filter dropdown.)
- **No sound notifications.** Visual only. (Future: optional desktop notification + sound, scheduled for Step 4 alert_manager.py.)

---

## Apollo Live v1.2 — Symbol-dropdown bugfix (Phase 2 Step 3)

**Date**: 2026-07-27
**Purpose**: Hotfix for v1.1. The dashboard's symbol dropdown was hardcoded to 5 test stocks (APOLLO, CYIENTDLM, SYRMA, JYOTICNC, KAYNES) but the zip only shipped `CYIENTDLM.csv` under `data/`. When users switched to SYRMA (or any stock without a CSV on disk), the dashboard threw `FileNotFoundError: CSV not found: ...SYRMA.csv` and the score chart went blank. v1.2 makes the dropdown dynamic and improves the missing-CSV error message.

### What's new

#### 1. `live_engine/dashboard.py` — dynamic symbol dropdown (bugfix)

- **New helper** `list_available_symbols(data_dir)`: scans `data_dir` for `*.csv` files, skips the `*_D.csv` / `*_4H.csv` / `*_W.csv` sidecars (intermediate files produced by `load_eod2_stock`), and returns a sorted list of available symbols — known test stocks first (in declared order), then any extras alphabetically.
- **Cached wrapper** `list_available_symbols_cached(data_dir)` with 60-second TTL so sidebar rerenders don't rescan the disk.
- **Sidebar now uses the cached list** for the symbol dropdown instead of the hardcoded `TEST_STOCKS`. If the data dir is empty/missing, the dropdown falls back to `TEST_STOCKS` plus a yellow warning telling the user to drop a CSV in `data/`.
- **New "↻ Refresh symbol list" button** in the sidebar — clears the cache and reruns. Use this after dropping a new CSV into `data/` so it appears in the dropdown without restarting the dashboard.
- **Default selection logic**: prefers `CYIENTDLM` (the regression baseline stock, always shipped in the zip), falls back to the first available symbol, and preserves the user's prior selection across reruns if it's still in the list.

#### 2. `live_engine/dashboard.py` — friendly missing-CSV error (bugfix)

`load_score_history()` now does an explicit pre-check before instantiating `BarReplay`:

- If `{data_dir}/{symbol}.csv` is missing → shows a red `st.error` with the exact expected file path and instructions ("Place `{symbol}.csv` in your data directory and click 'Refresh symbol list'"). Returns an empty DataFrame instead of throwing.
- Catches `FileNotFoundError` separately (in case `load_eod2_stock` raises it for another reason) with a similar friendly message.
- Catches all other exceptions as before.

This means: even if a user manages to submit a symbol with no CSV (e.g., by changing `data_dir` after the dropdown populated), they see a clear actionable error instead of a Python traceback.

#### 3. Version bumps

- `live_engine/__init__.py`: `__version__ = "1.2"`
- `live_engine/dashboard.py` docstring: `Phase 2 Step 3 (v1.2)`
- `live_engine/run_live.py` docstring: `Phase 2 Step 3 (v1.2)`
- `live_engine/cli.py` banner: `Apollo Live Engine v1.2 — Signal Monitor`
- `tests/preflight_live.py`: `CURRENT_VERSION = "v1.2"`, `CURRENT_VERSION_DOTTED = "1.2"`

### Compatibility

- **No breaking changes.** The bugfix is purely additive — no API signatures changed, no schema migrations, no behavior changes for stocks whose CSV is present.
- Existing `live_state.db` files from v1.0 / v1.1 continue to work unchanged.
- Users who already have all 5 test-stock CSVs in `data/` will see the same dropdown as before (all 5 selectable).

### How to test

1. Extract the zip to a clean folder.
2. Run `python live_engine/run_live.py` — dashboard opens, dropdown shows only `CYIENTDLM` (the only CSV shipped).
3. Try typing a custom symbol in the dropdown — only `CYIENTDLM` is offered.
4. Drop another CSV (e.g., `SYRMA.csv`) into `data/`, click "↻ Refresh symbol list" in the sidebar — `SYRMA` appears in the dropdown and is selectable.
5. Run `python tests/preflight_live.py` — all tests pass.

---

## Apollo Live v1.1 — Live dashboard + human-in-the-loop exit confirmation (Phase 2 Step 3)

**Date**: 2026-07-27
**Purpose**: First interactive live dashboard. Adds a Streamlit UI that shows real-time alerts, position state, score history chart with ENTRY/EXIT markers, and a "Confirm Exit" button so exits become human-confirmed (instead of auto-confirmed as in v1.0). This is the true human-in-the-loop live trading mode — the engine surfaces signals, the user decides whether to act.

### What's new

#### 1. `live_engine/dashboard.py` — Streamlit UI (new file, ~600 lines)

A single-page dashboard that reads from the same SQLite state store the monitor writes to. The monitor runs as a separate subprocess (started from the dashboard's "Start Monitor" button or from the CLI), and the dashboard polls the state store for live updates every 5 seconds.

**Layout**:
- **Sidebar** — symbol selector (5 test stocks pre-loaded), date range, exit mode + SL config, DB path, auto-confirm toggle, monitor controls, auto-refresh toggle.
- **KPI row** — 5 metric cards: Position status (FLAT / IN TRADE / PENDING EXIT / COOLDOWN), Latest Score, Entry Price, Last Alert type, Total Alert count.
- **Pending Exit panel** — appears only when an EXIT alert is pending. Shows exit reason, fill price, P&L, and provides:
  - **"✓ Confirm Exit"** button — calls `confirm_exit()` to reset position + set cooldown + emit `EXIT_CONFIRMED` alert.
  - **"✗ Dismiss"** button — calls `dismiss_exit()` to clear pending state but keep position open (for when the user disagrees with the signal).
  - Optional user note field (stored in the alert payload for audit trail).
- **Score History chart** — interactive Plotly chart showing daily score over the selected date range, with horizontal threshold lines (entry/exit) and markers:
  - Green ▲ for ENTRY alerts
  - Red ▼ for EXIT alerts
  - Gold ◆ for EXIT_CONFIRMED alerts
- **Recent alerts table** — last 50 alerts with timestamp, type, score, close, message.
- **Position State Details** (expandable) — full Position dataclass dump for debugging.

**Monitor process management**: The dashboard starts the monitor as a detached subprocess (`subprocess.Popen` with `start_new_session=True` on POSIX, `CREATE_NEW_PROCESS_GROUP` on Windows). PID is stored in `st.session_state.monitor_pid`. The "Stop Monitor" button sends SIGTERM (POSIX) or `taskkill /T /F` (Windows).

**Auto-refresh**: Uses `@st.fragment(run_every=timedelta(seconds=5))` to refresh the alerts panel every 5 seconds without re-running the whole page. Toggle in sidebar.

#### 2. `live_engine/run_live.py` — Single launcher (new file)

Convenience launcher that verifies project structure, prints a banner, and runs `streamlit run live_engine/dashboard.py` with sensible defaults:

```
python live_engine/run_live.py                  # default port 8501
python live_engine/run_live.py --port 8888      # custom port
python live_engine/run_live.py --no-browser     # don't auto-open browser
```

#### 3. `apollo_core/types.py` — added `pending_exit` + `pending_exit_payload` to Position

Two new fields on the `Position` dataclass:
- `pending_exit: bool = False` — True after an EXIT alert fires (in human-confirm mode) but before the user confirms.
- `pending_exit_payload: Optional[dict] = None` — saved ExitDecision payload (reason, fill_price, P&L, etc.) so the dashboard can show the user what triggered the exit without re-running detection.

These are inert in backtest mode (always False / None) and in v1.0's auto-confirm live mode. Backward compatible — no behavior change for existing callers.

#### 4. `live_engine/state_store.py` — schema migration for v1.0 databases

Added two new columns to `monitor_state`: `pending_exit` (INTEGER) and `pending_exit_payload` (TEXT). On opening a v1.0 database, the StateStore auto-runs `ALTER TABLE ADD COLUMN` for each (idempotent — silently skips if column already exists). Users can upgrade from v1.0 to v1.1 without losing their alert history or position state.

#### 5. `live_engine/signal_monitor.py` — human-confirm mode

When `auto_confirm_exit=False` (new default for the dashboard):
- First EXIT detection: emits `EXIT` alert + sets `pending_exit=True` + saves payload. Position is NOT reset.
- Subsequent bars while `pending_exit=True`: skip new exit detection (one pending at a time), emit `HOLD` with `PENDING_EXIT` flag so the alert log shows the wait.
- Two new module-level functions:
  - **`confirm_exit(state_store, symbol, ...)`** — reads Position, resets it, sets `cooldown_until_date` (in trading days, same as the monitor's logic), clears pending state, emits `EXIT_CONFIRMED` alert. Returns True if a pending exit was confirmed, False otherwise.
  - **`dismiss_exit(state_store, symbol, ...)`** — clears pending state but keeps `in_trade=True` and all entry/peak fields. Emits `EXIT_DISMISSED` alert. The monitor will resume exit detection on the next bar.

Two new alert types: `EXIT_CONFIRMED` and `EXIT_DISMISSED`.

#### 6. `live_engine/cli.py` — `--no-auto-confirm` flag

New CLI flag for headless human-confirm mode:

```
python -m live_engine --symbol CYIENTDLM --no-auto-confirm
```

The dashboard's "Start Monitor" button automatically passes this flag when "Auto-confirm exits" is unchecked in the sidebar.

#### 7. Pre-flight test suite — 21 tests (was 15)

Six new tests for v1.1 functionality:

| # | Test | Catches |
|---|---|---|
| 16 | dashboard.py imports cleanly | Broken import, missing main() |
| 17 | run_live.py launcher imports cleanly | Broken launcher, missing structure check |
| 18 | **CRITICAL: Human-confirm mode sets pending_exit** | The new mode is broken — EXIT alerts don't actually set pending state |
| 19 | confirm_exit() resets position | The confirm button doesn't actually close the position |
| 20 | dismiss_exit() keeps position open | The dismiss button accidentally closes the position |
| 21 | v1.0 DB auto-migrates to v1.1 | Users upgrading from v1.0 lose their state |

### How to run

**Quick start (dashboard):**
1. `pip install -r requirements.txt`
2. `python live_engine/run_live.py` (or double-click `run_apollo_live.bat` on Windows)
3. Pick a symbol + date range in the sidebar.
4. Uncheck "Auto-confirm exits" (default) for human-in-the-loop mode.
5. Click "▶ Start Monitor".
6. Watch alerts appear in real time. When an EXIT alert fires, click "✓ Confirm Exit" to close the position.

**Headless (CLI, auto-confirm):**
```
python -m live_engine --symbol CYIENTDLM --start 2024-01-01 --end 2024-06-30
```

**Headless (CLI, human-confirm):**
```
python -m live_engine --symbol CYIENTDLM --no-auto-confirm
```
Then open the dashboard separately to confirm/dismiss pending exits.

### Verification

All 21 preflight tests pass:
- Tests 1–15: same as v1.0 (syntax, imports, files, version consistency, BarReplay, StateStore roundtrip, monitor end-to-end, **byte-for-byte match with backtest**, crash-recovery, CLI, bat file).
- Test 9 enhanced: now verifies `pending_exit` and `pending_exit_payload` roundtrip through SQLite.
- Tests 16–21: new — see table above.

The critical correctness proof from v1.0 still holds: **live decisions match backtest decisions byte-for-byte** (Test 12). The human-confirm mode is a pure UI-layer addition — it doesn't change the detect logic, only what happens after detection.

### What's next (Step 4)

- `live_engine/alert_manager.py` — file log + Telegram notification for ENTRY/EXIT/EXIT_CONFIRMED alerts. Will let you monitor multiple stocks in parallel and get push notifications.
- `live_engine/config.yaml` — central config for monitor settings (symbols, thresholds, Telegram credentials).

### Built on

- **Apollo Live v1.0** — the monitor core (data_replay, state_store, signal_monitor) is unchanged in behavior. v1.1 adds the UI layer + pending_exit state on top.
- **Apollo Backtest v3.5** — the detect/execute split. The dashboard's confirm/dismiss buttons are the "execute" half that was missing from v1.0.

---

## Apollo Live v1.0 — Live engine core (Phase 2 Step 2)

**Date**: 2026-07-27
**Purpose**: First release of the live signal monitor. Uses the same `detect_exit_triggers()` function from `apollo_core/trade_engine.py` (introduced in backtest v3.5) to emit ADVISORY alerts — does NOT auto-execute trades. This is the foundation for live trading: human-in-the-loop decision-making powered by the same engine brain as the backtest.

### What's new

#### 1. `live_engine/` package — 5 new modules

- **`live_engine/__init__.py`** — Package marker, exports `__version__ = "1.0"`.
- **`live_engine/data_replay.py`** — `BarReplay` class. Loads eod2 CSV via `load_eod2_stock`, runs `run_backtest` (or `run_ipo_backtest` for IPO stocks) ONCE on the full date range to get all `daily_results`, then yields one `ReplayBar` namedtuple at a time. O(N) total — no O(N²) recomputation.
- **`live_engine/state_store.py`** — `StateStore` class. SQLite-backed persistence with two tables:
  - `monitor_state` (one row per symbol) — stores all `Position` dataclass fields + `last_processed_date` + `cooldown_until_date`.
  - `alerts` (append-only) — every emitted alert with timestamp, type, message, and JSON payload.
  - Supports `save_position()`, `load_position()`, `save_alert()`, `list_alerts()`, `count_alerts()`.
- **`live_engine/signal_monitor.py`** — `SignalMonitor` class. The core live loop. For each bar from `BarReplay`:
  1. Loads `Position` from `StateStore` (on first run) or uses in-memory state.
  2. If `in_trade`: updates peaks (peak_close, peak_rsi, trail_activation), then calls `detect_exit_triggers(bar, position, config)`. If `should_exit=True`, emits an `EXIT` advisory alert and (in Step 2) auto-resets position state. Step 3 will require human confirmation instead.
  3. If `not in_trade` and score ≥ entry_threshold: checks cooldown, then emits an `ENTRY` advisory alert and opens a virtual position.
  4. Saves state to `StateStore` after every bar.
- **`live_engine/cli.py`** + **`live_engine/__main__.py`** — Command-line interface. Run via `python -m live_engine --symbol CYIENTDLM --start 2024-01-01`. Supports `--list-alerts`, `--no-resume`, `--quiet`, and all exit-mode/threshold overrides.

#### 2. `apollo_core/types.py` — added `cooldown_until_date` field to `Position`

In backtest mode, `cooldown_until` is an int bar index. In live mode, the bar index changes each day as history grows, so we use `cooldown_until_date` (a `pd.Timestamp`) instead. The `cooldown_until` field is preserved for backtest compatibility (unchanged behavior). The new field defaults to `None` and is only populated in live mode.

#### 3. Trading-day-based cooldown (matches backtest exactly)

The first implementation used calendar days for cooldown (exit_date + N calendar days). This caused divergence from the backtest (which uses bar indices = trading days). Fixed by looking up `exit_date` in `df_d.index`, advancing by `divergence_cooldown_days` positions, and taking that trading-day as `cooldown_until_date`. Now produces byte-for-byte identical decisions to the backtest.

#### 4. State persistence — crash-recovery verified

The monitor saves state after every bar. On restart with `resume=True` (default), it:
1. Loads the saved `Position` and `last_processed_date`.
2. Skips all bars with `date <= last_processed_date`.
3. Processes new bars normally.

Verified by `tests/test_resume.py`: a single uninterrupted run produces identical decisions to a split run (first half → stop → resume → second half).

#### 5. Pre-flight test suite — 15 tests

`tests/preflight_live.py` — must pass before any live-engine zip is built. Key tests:

| # | Test | Catches |
|---|---|---|
| 1 | Syntax check all .py files | Import-time errors |
| 2 | `__future__` import ordering | The classic SyntaxError |
| 3 | Import all modules | Bad imports, missing deps |
| 4 | All required files present | Missing file in zip |
| 5 | requirements.txt valid | Missing critical packages |
| 6 | Version string consistency | Stale version strings |
| 7 | **CHANGELOG.md at project root** | The new rule from user |
| 8 | BarReplay loads CYIENTDLM | Data loading broken |
| 9 | StateStore save/load roundtrip | Position serialization bug |
| 10 | StateStore alert log | Alert persistence broken |
| 11 | SignalMonitor runs end-to-end | Monitor crashes mid-run |
| 12 | **CRITICAL: Live decisions match backtest** | The detect/execute split failed |
| 13 | Crash-recovery (resume after stop) | State persistence broken |
| 14 | CLI argparse | CLI broken |
| 15 | run_apollo_live.bat correctness | Launcher broken |

### Verification: byte-for-byte match with backtest

The critical correctness proof for Step 2. Ran both engines on CYIENTDLM with `exit_mode=NONE`:

| Date range | Backtest entries | Live entries | Backtest exits | Live exits | Match rate |
|---|---|---|---|---|---|
| 2024-01-01 → 2024-06-30 | 3 | 3 | 2 | 2 | 100% |
| 2023-01-01 → 2024-12-31 | 8 | 8 | 7 | 7 | 100% |
| 2022-01-01 → 2026-07-24 | 19 | 19 | 18 | 18 | 100% |

**Total: 30/30 entry decisions + 27/27 exit decisions match exactly.** The detect/execute split is verified correct — the live monitor uses the same brain as the backtest, with zero divergence.

Note: backtest emits an additional `PERIOD_END` exit at the end of the data range (closes any open position). The live monitor does NOT emit this, because in live mode there is no "end of data" — positions stay open until a real exit signal fires. This is the intended behavior, not a bug.

### How to run

**Quick start:**
1. `pip install -r requirements.txt`
2. Double-click `run_apollo_live.bat` (or run `python -m live_engine --symbol CYIENTDLM --data-dir data --start 2024-01-01`)

**View emitted alerts:**
```
python -m live_engine --symbol CYIENTDLM --list-alerts
```

**Run pre-flight suite:**
```
python tests/preflight_live.py
```

### What's next (Step 3)

- `live_engine/dashboard.py` — Streamlit UI showing live alerts, current position state, score history. Includes a "confirm exit" button so exits become human-confirmed (currently auto-confirmed in Step 2).
- `live_engine/run_live.py` — single launcher that starts the monitor + dashboard together.

### Built on

- **Apollo Backtest v3.5** — the detect/execute split introduced in v3.5 is the foundation. The live monitor uses `detect_exit_triggers()` directly (no duplication of exit logic).
- The `apollo_core/` package in this zip is identical to backtest v3.5's.

---

## v3.5 — Apollo Backtest: Detect-Execute Split (Phase 2 Step 1)

**Date**: 2026-07-27
**Purpose**: Refactor `extract_trades()` into a pure `detect_exit_triggers()` + `execute_exit()` + slimmed `extract_trades()`. This is the foundation that lets the same engine brain power both backtest (auto-execute) and live mode (advisory alerts) — coming in Phase 2 Step 2.

### What Changed

#### 1. New dataclasses in `apollo_core/types.py`
- **`Position`** — mutable state for one stock's trade lifecycle (in_trade, entry_*, peak_*, trail_activation, prev_di's, cooldown_until)
- **`ExitConfig`** — immutable config for exit detection (exit_mode, sl_percent, etc.) with computed `hard_sl_mult` / `trail_sl_mult` properties
- **`ExitDecision`** — pure output of `detect_exit_triggers()` (should_exit, fill_price, primary_reason, primary_class, all_triggered_reasons, individual trigger flags)

#### 2. New `detect_exit_triggers()` pure function in `apollo_core/trade_engine.py`
Reads `bar` + `position` + `config`, returns an `ExitDecision`. **Never mutates** position — all state updates happen in the caller. This is the function that will be called in live mode (Step 2) to evaluate exits without auto-executing them.

#### 3. New `execute_exit()` function in `apollo_core/trade_engine.py`
Takes an `ExitDecision`, appends the EXIT event to the events list, resets position to fresh state, sets cooldown. Used by backtest auto-execute. In live mode, the caller can either call this OR just emit an advisory alert.

#### 4. `extract_trades()` slimmed down
Now owns only:
- The per-bar loop
- Bar data lookups (open_price, plus_di, minus_di from `df_d`)
- Position-state updates that happen every bar while in trade (peak_close, peak_rsi, trail_activation)
- ENTRY / HOLD event construction
- Period-end exit

Delegates exit-condition evaluation to `detect_exit_triggers()` and exit application to `execute_exit()`. Same public signature — existing callers in `backtest.py` need no changes.

### Verification: byte-for-byte identical to v3.4.2

A frozen baseline of v3.4.2's CYIENTDLM trade output is saved at `tests/baseline_v342_cyientdlm.json`. **Test 13** in the pre-flight suite runs the current code's backtest on CYIENTDLM and compares every trade event field-by-field against this baseline.

---

## v3.4.2 — Apollo Backtest: Universe path bugfix + pre-flight test suite

**Date**: 2026-07-26
**Purpose**: Bugfix release on top of v3.4.1. Adds the pre-flight test suite.

### What Changed

- Universe file path bugfix (`backtest_engine/app.py`): use `Path(__file__).resolve().parent.parent` to walk up to project root.
- `__future__` import ordering fix in `app.py` and `types.py`.
- `run_apollo.bat` path fix: now correctly says `streamlit run backtest_engine\app.py`.
- Pre-flight test suite (`tests/preflight.py`) — 12 tests, must pass before any zip is built.

---

## v3.4.1 — Apollo Backtest: Bucket Ungated (reference-only classifier)

**Date**: 2026-07-26
**Purpose**: Phase 2 Step 0 — Remove bucket classifier as a gate, fix latent bug.

### What Changed

- Bucket classifier is now REFERENCE-ONLY (directive from user). Every stock reaches the Apollo engine, irrespective of bucket. The 21-signal system itself is the quality gate.
- `should_skip` return value removed from `classify_stock_bucket()`.
- Backward-compat alias `pre_filter_bucket()` retained (returns `(False, bucket, metrics)`).
- Guard comment block added in `apollo_core/trade_engine.py` above `total = raw_total`.

---

## v3.4 — Apollo Backtest: Phase 1 Refactored

**Date**: 2026-07-26
**Purpose**: Code restructured into `apollo_core/` (scoring brain) + `backtest_engine/` (Streamlit UI + I/O).
