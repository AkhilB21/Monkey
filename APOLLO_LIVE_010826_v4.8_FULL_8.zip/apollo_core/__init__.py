
"""Apollo Core — Shared scoring, trade logic, and indicators.

This package contains all pure-computation modules used by both
backtest_engine and (future) live_engine.  No I/O, no Streamlit.
"""

from apollo_core.constants import (
    ENTRY_THRESHOLD, EXIT_THRESHOLD, DIVERGENCE_RSI_DROP, DIVERGENCE_COOLDOWN,
    SIGNAL_DEFS, POOL_ORDER, POOL_MAX, POOL_NAMES, POOL_DESC,
    IPO_SIGNAL_DEFS, IPO_POOL_ORDER, IPO_POOL_MAX, IPO_POOL_NAMES,
    DEFAULT_MIN_TRADING_DAYS, EXIT_MODE_DEFS,
)
from apollo_core.types import TradeEvent, DailyResult, SignalResult
from apollo_core.scoring import (
    _graded, classify_score, detect_troughs, get_latest_trough_pos,
    compute_weekly_rsi, eval_signals, eval_ipo_signals, _normalize_ipo_score,
)
from apollo_core.trade_engine import run_backtest, run_ipo_backtest, extract_trades
from apollo_core.gates import compute_gate_frame, evaluate_gate_row
from apollo_core.fundamentals import load_fundamental_profile

__all__ = [
    "ENTRY_THRESHOLD", "EXIT_THRESHOLD", "DIVERGENCE_RSI_DROP", "DIVERGENCE_COOLDOWN",
    "SIGNAL_DEFS", "POOL_ORDER", "POOL_MAX", "POOL_NAMES", "POOL_DESC",
    "IPO_SIGNAL_DEFS", "IPO_POOL_ORDER", "IPO_POOL_MAX", "IPO_POOL_NAMES",
    "DEFAULT_MIN_TRADING_DAYS", "EXIT_MODE_DEFS",
    "TradeEvent", "DailyResult", "SignalResult",
    "_graded", "classify_score", "detect_troughs", "get_latest_trough_pos",
    "compute_weekly_rsi", "eval_signals", "eval_ipo_signals", "_normalize_ipo_score",
    "run_backtest", "run_ipo_backtest", "extract_trades",
    "compute_gate_frame", "evaluate_gate_row", "load_fundamental_profile",
]
