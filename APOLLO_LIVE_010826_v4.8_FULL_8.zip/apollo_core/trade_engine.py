"""Apollo Core — Trade Engine Module (v4.8)

Core trade logic: backtest loop, exit detection, trade extraction.
v4.8: Gates G1-G4 converted to informational (dict return, never block).
       Gate-blocking events removed. Renko Pool R wired into scoring loop
       (r_points passed to classify_score). RENKO_HARD_GATE set to 0.
No disk I/O — data frames passed in.

Functions:
    run_backtest          — main scoring loop for mature stocks
    run_ipo_backtest      — IPO-specific scoring loop
    extract_trades        — OR-based trade extraction with selectable exit mode
                            (loop owner; calls detect_exit_triggers + execute_exit)
    detect_exit_triggers  — PURE: evaluate all exit conditions for one bar,
                            return an ExitDecision (no side effects)
    execute_exit          — apply an ExitDecision (append event, reset position,
                            set cooldown). Used by backtest auto-execute.
                            Live mode will call detect only and emit an alert.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from apollo_core.constants import (
    ENTRY_THRESHOLD,
    EXIT_THRESHOLD,
    DIVERGENCE_RSI_DROP,
    DIVERGENCE_COOLDOWN,
    SIGNAL_DEFS,
    POOL_ORDER,
    POOL_MAX,
    POOL_NAMES,
    POOL_DESC,
    IPO_SIGNAL_DEFS,
    IPO_POOL_ORDER,
    IPO_POOL_MAX,
    IPO_POOL_NAMES,
    DEFAULT_MIN_TRADING_DAYS,
)
from apollo_core.indicators import compute_all_indicators
from apollo_core.bucket_classifier import (
    compute_bucket_metrics,
    classify_bucket,
    get_score_multiplier,
    SKIP_BUCKETS,
)
from apollo_core.ipo_lookup import is_ipo_by_listing_date, get_listing_close_price
from apollo_core.scoring import (
    _graded, classify_score, detect_troughs, get_latest_trough_pos,
    compute_weekly_rsi, eval_signals, eval_ipo_signals, _normalize_ipo_score,
)
from apollo_core.gates import compute_gate_frame, evaluate_gate_row
from apollo_core.types import Position, ExitConfig, ExitDecision


def run_ipo_backtest(
    df_d: pd.DataFrame,
    df_4h: pd.DataFrame,
    start_date: str,
    end_date: str,
    entry_threshold: float = 70,
    exit_threshold: float = 50,
    listing_close: float | None = None,
) -> tuple[pd.DataFrame, list]:
    """Run the IPO-specific scoring loop.

    This is a parallel implementation to ``run_backtest`` that uses
    ``eval_ipo_signals`` instead of ``eval_signals``.  The raw score
    (out of 69) is normalized to 0-100 before applying entry/exit logic.

    Returns
    -------
    (daily_df, daily_results, trades)
    """
    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    mask = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    mask_arr = np.asarray(mask)
    daily_indices = np.where(mask_arr)[0]
    if len(daily_indices) == 0:
        return pd.DataFrame(), [], []

    # Pre-compute 4H alignment via searchsorted (fast)
    d_dates = df_d.index.values.astype('datetime64[ns]')
    h_dates = df_4h.index.values.astype('datetime64[ns]')
    h_idx_for_daily = np.searchsorted(h_dates, d_dates, side='right') - 1

    daily_results: list[dict] = []
    for pos in daily_indices:
        bt_date = df_d.index[pos]

        # Resolve 4H bar: O(1) lookup instead of O(N) np.where scan
        h_idx = h_idx_for_daily[pos]
        if h_idx < 0:
            continue

        # Evaluate IPO signals (pass actual listing close if available)
        sigs = eval_ipo_signals(df_d, df_4h, pos, h_idx, listing_close=listing_close)

        # Aggregate pool points
        pool_pts: dict[str, float] = {}
        for pool_id in IPO_POOL_ORDER:
            pool_pts[pool_id] = sum(
                sigs[sid][0] for sid, _, pool, _ in IPO_SIGNAL_DEFS if pool == pool_id
            )

        raw_total = sum(pool_pts.values())
        total = _normalize_ipo_score(raw_total)

        action, pos_pct = classify_score(total, r_points=r_points)

        daily_results.append({
            "date": bt_date,
            "close": df_d["close"].iloc[pos],
            "pool_a": pool_pts.get("IM", 0),
            "pool_b": pool_pts.get("IS", 0),
            "pool_c": pool_pts.get("IV", 0),
            "bonus_a": 0.0,
            "bonus_b": 0.0,
            "bonus_c": 0.0,
            "core": round(total, 2),
            "bonus": 0.0,
            "raw_total": round(raw_total, 2),
            "total": round(total, 2),
            "bucket": "IPO / New Listing",
            "bucket_multiplier": 1.00,
            "action": action,
            "pos_pct": pos_pct,
            "signals": sigs,
            "is_ipo": True,
            "d_trough_pos": None,
            "bars_from_trough": None,
            "rsi21": df_d["rsi21"].iloc[pos] if "rsi21" in df_d.columns else np.nan,
        })

    # Build daily DataFrame
    daily_df = pd.DataFrame(
        [{k: v for k, v in r.items() if k != "signals"} for r in daily_results]
    )
    if daily_df.empty:
        return daily_df, [], []

    # Trade extraction uses the same logic — scores are already 0-100
    trades = extract_trades(
        daily_results, df_d,
        exit_mode="NONE",
        divergence_rsi_drop=DIVERGENCE_RSI_DROP,
        divergence_cooldown=DIVERGENCE_COOLDOWN,
        exit_threshold=exit_threshold,
        entry_threshold=entry_threshold,
    )
    return daily_df, daily_results, trades


# =========================================================================
# Main scoring loop (mature stocks — unchanged)
# =========================================================================

def run_backtest(
    df_d: pd.DataFrame,
    df_4h: pd.DataFrame,
    df_w: pd.DataFrame,
    start_date: str,
    end_date: str,
    entry_threshold: float = 70,
    exit_threshold: float = 50,
    pe: float | None = None,
) -> tuple[pd.DataFrame, list]:
    """Run the full Apollo scoring loop.

    Parameters
    ----------
    df_d, df_4h, df_w : pd.DataFrame
        Daily, 4H, weekly DataFrames with indicator aliases.
    start_date, end_date : str
        Inclusive date range (YYYY-MM-DD or parseable by pandas).
    entry_threshold, exit_threshold : float
        Override the module-level thresholds.
    pe : float or None
        Trailing PE for the G1 informational gate display. ``None`` skips G1.

    Returns
    -------
    (daily_df, daily_results, trades)
        daily_df      — one row per trading day with scores + pool breakdowns.
        daily_results — raw list of dicts including 'signals' key (for drilldown).
        trades        — list of event dicts (entries/exits/holds).
    """
    # --- Pre-compute indicator series ---
    d_rsi21 = df_d["rsi21"]
    d_rsi36 = df_d["rsi36"]
    d_rsi56 = df_d["rsi56"]
    h_rsi21 = df_4h["rsi21"]
    h_rsi36 = df_4h["rsi36"]
    w_rsi21 = compute_weekly_rsi(df_w, 21)
    w_rsi56 = compute_weekly_rsi(df_w, 56)
    plus_di = df_d["plus_di"]
    minus_di = df_d["minus_di"]
    macd_line = df_d["macd"]

    # --- Bucket classifier metrics (computed once for the entire series) ---
    bucket_metrics = compute_bucket_metrics(df_d)

    # --- Gate display values (v4.8) — pre-computed once per run, informational only ---
    gate_frame = compute_gate_frame(df_d)

    # --- Detect troughs ---
    d_troughs = detect_troughs(d_rsi21, 40.0, 11)
    h_troughs = detect_troughs(h_rsi21, 38.0, 5)

    # --- Pre-compute WC21 crossover prices for B6 ---
    crossover_prices: list[float | None] = []
    prev_above = False
    xover_price: float | None = None
    for i in range(len(df_4h)):
        c = df_4h["close"].iloc[i]
        w = df_4h["wc21"].iloc[i] if "wc21" in df_4h.columns else np.nan
        if np.isnan(c) or np.isnan(w):
            prev_above = False
            crossover_prices.append(None)
            continue
        cur_above = c > w
        if cur_above and not prev_above:
            xover_price = c
        elif not cur_above:
            xover_price = None
        prev_above = cur_above
        crossover_prices.append(xover_price)

    # --- Date range filtering ---
    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    mask = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    mask_arr = np.asarray(mask)
    daily_indices = np.where(mask_arr)[0]
    if len(daily_indices) == 0:
        return pd.DataFrame(), []

    # --- Pre-compute 4H / weekly alignment via searchsorted (fast) ---
    d_dates = df_d.index.values.astype('datetime64[ns]')
    h_dates = df_4h.index.values.astype('datetime64[ns]')
    w_dates = df_w.index.values.astype('datetime64[ns]')

    # For each daily bar, find the index of the last 4H/weekly bar <= that date
    h_idx_for_daily = np.searchsorted(h_dates, d_dates, side='right') - 1
    w_idx_for_daily = np.searchsorted(w_dates, d_dates, side='right') - 1

    # --- Main scoring loop ---
    daily_results: list[dict] = []
    for pos in daily_indices:
        bt_date = df_d.index[pos]

        # Resolve 4H bar: O(1) lookup instead of O(N) np.where scan
        h_idx = h_idx_for_daily[pos]
        if h_idx < 0:
            continue

        # Resolve weekly bar: O(1) lookup
        w_idx = w_idx_for_daily[pos]
        if w_idx < 0:
            continue

        # Trough positions
        d_trough_pos = get_latest_trough_pos(d_troughs, pos)
        h_trough_pos = get_latest_trough_pos(h_troughs, h_idx)

        # B6 crossover price
        b6_xover = crossover_prices[h_idx] if h_idx < len(crossover_prices) else None

        # Evaluate all signals
        sigs = eval_signals(
            df_d, df_4h, df_w, pos, h_idx, w_idx,
            d_trough_pos, h_trough_pos,
            d_rsi21, d_rsi36, h_rsi21, h_rsi36,
            w_rsi21, w_rsi56,
            plus_di, minus_di, macd_line,
            b6_xover,
        )

        # Aggregate pool points
        pool_pts: dict[str, float] = {}
        for pool_id in POOL_ORDER:
            pool_pts[pool_id] = sum(
                sigs[sid][0] for sid, _, pool, _ in SIGNAL_DEFS if pool == pool_id
            )

        core = min(100, pool_pts["A"] + pool_pts["B"] + pool_pts["C"])
        bonus = pool_pts["BA"] + pool_pts["BB"] + pool_pts["BC"] + pool_pts["BD"]
        r_points = pool_pts["R"]  # v4.8: Renko Pool R points (additive, max 27)
        raw_total = core + bonus + pool_pts["E"] + r_points

        # --- Layer 2: Per-bar bucket classification (informational only) ---
        bucket = classify_bucket(bucket_metrics, pos)
        multiplier = get_score_multiplier(bucket)  # recorded for transparency

        # --- Gate display values (v4.8) — informational only, never block entry ---
        gate_values = {}
        if pos < len(gate_frame):
            g_row = gate_frame.iloc[pos]
            g_row = g_row.copy()
            g_row["close"] = df_d["close"].iloc[pos]
            gate_values = evaluate_gate_row(g_row, pe=pe)

        # ═══════════════════════════════════════════════════════════════════
        # BUCKET IS REFERENCE-ONLY — multiplier is recorded for display, NEVER applied.
        # Every stock reaches the Apollo engine with its raw score intact.
        # A "Structural Decline" stock will naturally score low (RSI troughs
        # won't fire, recovery momentum won't trigger, etc.) and never reach
        # the 70-point entry threshold — the 21-signal system IS the gate.
        # Do NOT change this line without explicit user approval.
        # ═══════════════════════════════════════════════════════════════════
        total = raw_total  # bucket does NOT suppress score

        action, pos_pct = classify_score(total, r_points=r_points)

        daily_results.append({
            "date": bt_date,
            "close": df_d["close"].iloc[pos],
            "pool_a": pool_pts["A"],
            "pool_b": pool_pts["B"],
            "pool_c": pool_pts["C"],
            "bonus_a": pool_pts["BA"],
            "bonus_b": pool_pts["BB"],
            "bonus_c": pool_pts["BC"],
            "bonus_d": pool_pts["BD"],
            "bonus_e": pool_pts["E"],
            "pool_r": pool_pts["R"],
            "core": core,
            "bonus": bonus,
            "raw_total": round(raw_total, 2),
            "total": round(total, 2),
            "bucket": bucket,
            "bucket_multiplier": multiplier,
            "gate_values": gate_values,
            "action": action,
            "pos_pct": pos_pct,
            "signals": sigs,
            "d_trough_pos": d_trough_pos,
            "bars_from_trough": pos - d_trough_pos if d_trough_pos is not None else None,
            "rsi21": d_rsi21.iloc[pos],
        })

    # Build daily DataFrame (exclude signals dict)
    daily_df = pd.DataFrame(
        [{k: v for k, v in r.items() if k != "signals"} for r in daily_results]
    )
    if daily_df.empty:
        return daily_df, [], []

    # --- Trade extraction (default: NONE mode for backward compat) ---
    trades = extract_trades(
        daily_results, df_d,
        exit_mode="NONE",
        divergence_rsi_drop=DIVERGENCE_RSI_DROP,
        divergence_cooldown=DIVERGENCE_COOLDOWN,
        exit_threshold=exit_threshold,
        entry_threshold=entry_threshold,
    )
    return daily_df, daily_results, trades


# =========================================================================
# Trade extraction — OR-based exits with DUAL_SL support (v3.1)
# Refactored in v3.5: split into detect_exit_triggers() (pure) + execute_exit()
# + extract_trades() (loop owner). Same behavior, byte-for-byte identical output.
# =========================================================================

def detect_exit_triggers(
    bar: dict,
    position: Position,
    config: ExitConfig,
) -> ExitDecision:
    """PURE: Evaluate ALL exit conditions for one bar.

    This function reads ``position`` and ``bar`` but **never mutates** them.
    All position-state updates (peak_close, peak_rsi, trail_activation) happen
    in the caller (``extract_trades``) BEFORE invoking this function.

    Exit conditions are evaluated independently (OR-based). Every triggered
    reason is recorded. The highest-priority trigger determines fill price
    and classification; all others are appended as ``ALSO: ...``.

    Exit priority (for fill-price selection):
        1. HARD_SL / TRAILING_SL — gap-down aware fills
        2. DIVERGENCE
        3. DI_CROSSOVER
        4. SCORE_THRESHOLD

    Parameters
    ----------
    bar : dict
        One bar of data, pre-assembled by the caller. Required keys:
        ``date, close, score, rsi, action, open_price, plus_di, minus_di,
        bars_from_trough, pool_a, pool_b, pool_c, bonus_a, bonus_b, bonus_c``.
    position : Position
        Current position state (read-only here). Must have ``in_trade=True``;
        the caller decides whether to even call this function.
    config : ExitConfig
        Exit configuration (exit_mode, sl_percent, etc.).

    Returns
    -------
    ExitDecision
        If ``should_exit=False``, all other fields are at their defaults.
        If ``should_exit=True``, ``fill_price``, ``primary_reason``,
        ``primary_class`` and ``all_triggered_reasons`` are populated.
    """
    if not position.in_trade:
        return ExitDecision()

    close = bar["close"]
    open_price = bar["open_price"]
    score = bar["score"]
    rsi = bar["rsi"]
    cur_plus_di = bar["plus_di"]
    cur_minus_di = bar["minus_di"]

    entry_price = position.entry_price
    peak_rsi = position.peak_rsi
    peak_rsi_price = position.peak_rsi_price
    peak_close = position.peak_close
    prev_plus_di = position.prev_plus_di
    prev_minus_di = position.prev_minus_di
    trail_activation_price = position.trail_activation_price

    triggered_reasons: list[str] = []

    # 1. Hard SL check
    hard_sl_hit = False
    hard_sl_fill = None
    if config.exit_mode in ("FIXED_SL", "DUAL_SL") and config.sl_percent > 0:
        sl_price = entry_price * config.hard_sl_mult
        if close <= sl_price or open_price <= sl_price:
            hard_sl_hit = True
            hard_sl_fill = min(open_price, sl_price)
            triggered_reasons.append(
                f"HARD_SL (-{config.sl_percent}% from entry "
                f"{entry_price:.2f}, fill {hard_sl_fill:.2f})"
            )

    # 2. Trailing SL check
    trail_sl_hit = False
    trail_sl_fill = None
    if config.exit_mode in ("TRAILING_SL", "DUAL_SL") and config.trailing_sl_percent > 0:
        # In TRAILING_SL mode, always active.
        # In DUAL_SL mode, only active after activation threshold.
        trail_active = True
        if config.exit_mode == "DUAL_SL" and trail_activation_price is not None:
            trail_active = False
        if trail_active and peak_close is not None:
            trail_price = peak_close * config.trail_sl_mult
            if close <= trail_price or open_price <= trail_price:
                trail_sl_hit = True
                trail_sl_fill = min(open_price, trail_price)
                triggered_reasons.append(
                    f"TRAILING_SL (-{config.trailing_sl_percent}% from peak "
                    f"{peak_close:.2f}, fill {trail_sl_fill:.2f})"
                )

    # 3. Divergence check
    div_hit = False
    if (peak_rsi is not None and peak_rsi_price is not None
            and close > peak_rsi_price
            and rsi < (peak_rsi - config.divergence_rsi_drop)):
        div_hit = True
        rsi_drop = round(peak_rsi - rsi, 2)
        strength = "STRONG" if rsi_drop > 5 else "MODERATE"
        triggered_reasons.append(
            f"DIVERGENCE ({strength}, RSI {peak_rsi:.2f}->{rsi:.2f}, "
            f"drop={rsi_drop}pts)"
        )

    # 4. DI Crossover check
    di_hit = False
    if (config.exit_mode == "DI_CROSSOVER"
            and prev_plus_di is not None and prev_minus_di is not None
            and not np.isnan(cur_plus_di) and not np.isnan(cur_minus_di)
            and prev_plus_di > prev_minus_di
            and cur_plus_di < cur_minus_di):
        di_hit = True
        triggered_reasons.append(
            f"DI_CROSSOVER (+DI {prev_plus_di:.1f}->{cur_plus_di:.1f}, "
            f"-DI {prev_minus_di:.1f}->{cur_minus_di:.1f})"
        )

    # 5. Score threshold check
    score_hit = False
    if score < config.exit_threshold:
        score_hit = True
        triggered_reasons.append(
            f"SCORE<{config.exit_threshold} (score={score:.1f})"
        )

    if not triggered_reasons:
        return ExitDecision()

    # Pick fill price and classification by priority
    if hard_sl_hit:
        fill = hard_sl_fill
        primary_reason = [r for r in triggered_reasons if r.startswith("HARD_SL")][0]
        primary_class = "SL EXIT"
    elif trail_sl_hit:
        fill = trail_sl_fill
        primary_reason = [r for r in triggered_reasons if r.startswith("TRAILING_SL")][0]
        primary_class = "TRAILING SL EXIT"
    elif div_hit:
        fill = close
        primary_reason = [r for r in triggered_reasons if r.startswith("DIVERGENCE")][0]
        primary_class = "DIVERGENCE EXIT"
    elif di_hit:
        fill = close
        primary_reason = [r for r in triggered_reasons if r.startswith("DI_CROSSOVER")][0]
        primary_class = "DI CROSSOVER EXIT"
    else:
        fill = close
        primary_reason = triggered_reasons[0]
        primary_class = "EXIT"

    return ExitDecision(
        should_exit=True,
        fill_price=fill,
        primary_reason=primary_reason,
        primary_class=primary_class,
        all_triggered_reasons=triggered_reasons,
        hard_sl_hit=hard_sl_hit,
        trail_sl_hit=trail_sl_hit,
        div_hit=div_hit,
        di_hit=di_hit,
        score_hit=score_hit,
    )


def execute_exit(
    decision: ExitDecision,
    bar: dict,
    position: Position,
    events: list,
    config: ExitConfig,
    bar_index: int,
) -> None:
    """Apply an ExitDecision: append EXIT event, reset position, set cooldown.

    Used by backtest auto-execute. In live mode, the caller can either
    call this OR just log the decision as an advisory alert.

    Mutates ``position`` (resets to fresh state) and appends to ``events``.

    Parameters
    ----------
    decision : ExitDecision
        Output of ``detect_exit_triggers()``. Must have ``should_exit=True``.
    bar : dict
        The current bar (same dict passed to ``detect_exit_triggers``).
    position : Position
        Current position state. Will be reset to fresh (in_trade=False).
    events : list
        Event list to append the EXIT event to.
    config : ExitConfig
        Exit configuration (used for ``divergence_cooldown``).
    bar_index : int
        Index of the current bar in the daily_results list. Used to set
        ``cooldown_until = bar_index + divergence_cooldown``.
    """
    entry_price = position.entry_price
    entry_date = position.entry_date
    fill_price = decision.fill_price

    pnl = (fill_price - entry_price) / entry_price * 100.0

    # Build reason string: PRIMARY: X | ALSO: Y | ALSO: Z
    parts = [f"PRIMARY: {decision.primary_reason}"]
    for reason in decision.all_triggered_reasons:
        if reason != decision.primary_reason:
            parts.append(f"ALSO: {reason}")
    full_reason = " | ".join(parts)

    events.append({
        "type": "EXIT",
        "date": bar["date"],
        "close": fill_price,
        "score": round(bar["total"], 2),
        "classification": decision.primary_class,
        "entry_price": entry_price,
        "entry_date": entry_date,
        "pnl": round(pnl, 2),
        "exit_reason": full_reason,
        "bars_from_trough": bar["bars_from_trough"],
        "pool_a": round(bar["pool_a"], 2),
        "pool_b": round(bar["pool_b"], 2),
        "pool_c": round(bar["pool_c"], 2),
        "bonus": round(bar["bonus_a"] + bar["bonus_b"] + bar["bonus_c"] + bar.get("bonus_d", 0.0) + bar.get("bonus_e", 0.0), 2),
    })

    # Reset position to fresh state
    position.in_trade = False
    position.entry_price = None
    position.entry_date = None
    position.peak_rsi = None
    position.peak_rsi_price = None
    position.peak_rsi_date = None
    position.peak_close = None
    position.trail_activation_price = None
    # prev_plus_di / prev_minus_di are NOT reset here — they are updated
    # every bar in the main loop (independent of trade state).
    position.cooldown_until = bar_index + config.divergence_cooldown


def extract_trades(
    daily_results: list[dict],
    df_d: pd.DataFrame,
    exit_mode: str = "FIXED_SL",
    sl_percent: float = 5.0,
    trailing_sl_percent: float = 3.0,
    trailing_activate_pct: float = 5.0,
    divergence_rsi_drop: float = 3.0,
    divergence_cooldown: int = 5,
    exit_threshold: float = 50,
    entry_threshold: float = 70,
) -> list[dict]:
    """Extract trades from daily scoring results.

    Loop owner. Owns the per-bar iteration, position-state updates,
    ENTRY/HOLD events, and the period-end exit. Delegates exit-condition
    evaluation to ``detect_exit_triggers()`` (pure) and exit application
    to ``execute_exit()``.

    Exit logic is OR-based: ALL exit conditions are evaluated independently
    every bar.  Every triggered reason is recorded.  The highest-priority
    trigger determines the fill price and classification; all others are
    appended as ``ALSO: ...`` in exit_reason.

    Exit priority (for fill-price selection):
        1. HARD_SL  / TRAILING_SL  — gap-down aware fills
        2. DIVERGENCE
        3. DI_CROSSOVER
        4. SCORE_THRESHOLD
        5. PERIOD_END  (only at end of data)

    Exit Modes
    ----------
    ``NONE``         — score<exit_threshold + divergence exits only.
    ``FIXED_SL``     — hard SL from entry (gap-down aware).
    ``TRAILING_SL``  — SL trails from peak close.
    ``DUAL_SL``      — hard SL always on + optional trailing SL.
                       Uses *sl_percent* for hard, *trailing_sl_percent*
                       for trail.  Trailing activates only after price
                       rises *trailing_activate_pct* % above entry.
    ``DI_CROSSOVER`` — exit on +DI crossing below -DI.

    Parameters
    ----------
    daily_results : list[dict]
        Output rows from ``run_backtest`` (must include 'signals' key).
    df_d : pd.DataFrame
        Daily OHLCV DataFrame (used for open/high/plus_di/minus_di lookups).
    exit_mode : str
        One of: NONE, FIXED_SL, TRAILING_SL, DUAL_SL, DI_CROSSOVER.
    sl_percent : float
        Hard stop-loss percentage (used by FIXED_SL and DUAL_SL).
    trailing_sl_percent : float
        Trailing stop-loss percentage (used by TRAILING_SL and DUAL_SL).
    trailing_activate_pct : float
        Price must rise this % above entry before trailing SL activates.
    divergence_rsi_drop : float
        RSI must drop this many pts below peak to trigger divergence exit.
    divergence_cooldown : int
        Trading days after any non-score exit before re-entry allowed.
    exit_threshold : float
        Score below which an in-trade position is exited.
    entry_threshold : float
        Score at or above which a new entry is allowed.

    Returns
    -------
    list[dict] — event dicts with keys: type, date, close, score, …
    """
    events: list[dict] = []
    position = Position()
    config = ExitConfig(
        exit_mode=exit_mode,
        sl_percent=sl_percent,
        trailing_sl_percent=trailing_sl_percent,
        trailing_activate_pct=trailing_activate_pct,
        divergence_rsi_drop=divergence_rsi_drop,
        divergence_cooldown=divergence_cooldown,
        exit_threshold=exit_threshold,
        entry_threshold=entry_threshold,
    )

    for i, r in enumerate(daily_results):
        date = r["date"]
        score = r["total"]
        close = r["close"]
        rsi = r["rsi21"]
        action = r["action"]

        # Look up bar-level data from df_d (open, plus_di, minus_di, high)
        try:
            open_price = df_d["open"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            open_price = close
        try:
            cur_plus_di = df_d["plus_di"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            cur_plus_di = np.nan
        try:
            cur_minus_di = df_d["minus_di"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            cur_minus_di = np.nan

        # Pack everything detect_exit_triggers needs into a bar dict
        bar = {
            "date": date,
            "close": close,
            "score": score,
            "total": r["total"],
            "rsi": rsi,
            "action": action,
            "open_price": open_price,
            "plus_di": cur_plus_di,
            "minus_di": cur_minus_di,
            "bars_from_trough": r["bars_from_trough"],
            "pool_a": r["pool_a"],
            "pool_b": r["pool_b"],
            "pool_c": r["pool_c"],
            "bonus_a": r["bonus_a"],
            "bonus_b": r["bonus_b"],
            "bonus_c": r["bonus_c"],
            "bonus_d": r.get("bonus_d", 0.0),
            "gate_values": r.get("gate_values", {}),
        }

        # ============================================================ IN TRADE
        if position.in_trade:
            # --- State updates (happen every bar while in trade) ---
            # 1. Update peak_close (used by trailing SL)
            if close > position.peak_close:
                position.peak_close = close

            # 2. Update peak_rsi (used by divergence)
            if position.peak_rsi is not None and rsi > position.peak_rsi:
                position.peak_rsi = rsi
                try:
                    position.peak_rsi_price = df_d["high"].iloc[df_d.index.get_loc(date)]
                except (KeyError, ValueError):
                    position.peak_rsi_price = close
                position.peak_rsi_date = date

            # 3. Check trailing activation (DUAL_SL only)
            if config.exit_mode == "DUAL_SL" and position.trail_activation_price is not None:
                if close >= position.trail_activation_price:
                    position.trail_activation_price = None  # activated

            # --- Pure detection ---
            decision = detect_exit_triggers(bar, position, config)

            # --- Execute if any exit triggered ---
            if decision.should_exit:
                execute_exit(decision, bar, position, events, config, i)
                position.prev_plus_di = cur_plus_di
                position.prev_minus_di = cur_minus_di
                continue

            # --- No exit triggered — HOLD ---
            if score >= 90:
                hold_type = "HOLD-FULL STRONG"
            elif score >= 80:
                hold_type = "HOLD-FULL"
            elif score >= 70:
                hold_type = "HOLD-STD"
            else:
                hold_type = "WATCHLIST"
            events.append({
                "type": hold_type,
                "date": date,
                "close": close,
                "score": round(score, 2),
                "classification": action,
                "entry_price": position.entry_price,
                "entry_date": position.entry_date,
                "bars_from_trough": r["bars_from_trough"],
                "pool_a": round(r["pool_a"], 2),
                "pool_b": round(r["pool_b"], 2),
                "pool_c": round(r["pool_c"], 2),
                "bonus": round(r["bonus_a"] + r["bonus_b"] + r["bonus_c"] + r.get("bonus_d", 0.0) + r.get("bonus_e", 0.0), 2),
            })
            position.prev_plus_di = cur_plus_di
            position.prev_minus_di = cur_minus_di
            continue

        # ======================================================== NOT IN TRADE
        if not position.in_trade and score >= entry_threshold:
            if position.cooldown_until is not None and i < position.cooldown_until:
                position.prev_plus_di = cur_plus_di
                position.prev_minus_di = cur_minus_di
                continue

            # v4.8: Gates are informational only — no blocking.
            # Score alone decides entry.
            position.in_trade = True
            position.entry_price = close
            position.entry_date = date
            position.peak_rsi = rsi
            try:
                position.peak_rsi_price = df_d["high"].iloc[df_d.index.get_loc(date)]
            except (KeyError, ValueError):
                position.peak_rsi_price = close
            position.peak_rsi_date = date
            position.peak_close = close

            # Set trailing activation threshold for DUAL_SL
            if config.exit_mode == "DUAL_SL" and trailing_activate_pct > 0:
                position.trail_activation_price = position.entry_price * (1.0 + trailing_activate_pct / 100.0)
            else:
                position.trail_activation_price = None

            events.append({
                "type": "ENTRY",
                "date": date,
                "close": close,
                "score": round(score, 2),
                "classification": action,
                "entry_price": close,
                "entry_date": date,
                "bars_from_trough": r["bars_from_trough"],
                "pool_a": round(r["pool_a"], 2),
                "pool_b": round(r["pool_b"], 2),
                "pool_c": round(r["pool_c"], 2),
                "bonus": round(r["bonus_a"] + r["bonus_b"] + r["bonus_c"] + r.get("bonus_d", 0.0) + r.get("bonus_e", 0.0), 2),
            })

        position.prev_plus_di = cur_plus_di
        position.prev_minus_di = cur_minus_di

    # --- Period-end exit for any open trade ---
    if position.in_trade and daily_results:
        last = daily_results[-1]
        pnl = (last["close"] - position.entry_price) / position.entry_price * 100.0
        events.append({
            "type": "EXIT",
            "date": last["date"],
            "close": last["close"],
            "score": round(last["total"], 2),
            "classification": "EXIT",
            "entry_price": position.entry_price,
            "entry_date": position.entry_date,
            "pnl": round(pnl, 2),
            "exit_reason": "PERIOD_END",
            "bars_from_trough": last["bars_from_trough"],
            "pool_a": round(last["pool_a"], 2),
            "pool_b": round(last["pool_b"], 2),
            "pool_c": round(last["pool_c"], 2),
            "bonus": round(last["bonus_a"] + last["bonus_b"] + last["bonus_c"] + last.get("bonus_d", 0.0), 2),
        })

    return events


# =========================================================================
# High-level: load → score → extract → KPIs
# =========================================================================
# =========================================================================
# High-level: load → score → extract → KPIs
# =========================================================================
