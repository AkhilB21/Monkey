"""Apollo Live Engine — Signal Monitor Module.

The core live loop. Iterates over bars from ``BarReplay``, maintains
position state in ``StateStore``, and uses the SAME ``detect_exit_triggers()``
function that powers the backtest to emit ADVISORY alerts.

Critical difference from backtest
---------------------------------
In backtest mode, ``extract_trades()`` calls ``execute_exit()`` to
AUTOMATICALLY close the position (reset state, set cooldown). In live
mode, ``SignalMonitor`` calls ``detect_exit_triggers()`` ONLY to detect
the exit condition, then emits an advisory alert. The position is NOT
auto-closed — the user (or a future auto-trader) decides whether to act
on the alert.

Why? Because live mode is for human-in-the-loop decision-making. The
engine's job is to surface signals, not execute trades. When you (the
user) see an EXIT alert, YOU click "sell" in your broker terminal. The
monitor then waits for you to confirm the exit before resetting state
(Step 3 will add a "confirm exit" button in the dashboard).

For Step 2, the monitor auto-confirms exits after emitting the alert
(since there's no UI yet). This lets us verify the detect/execute
split produces identical decisions to the backtest. Step 3 will
introduce the human-in-the-loop confirmation.

Alert types
-----------
    ENTRY           — score crossed above entry_threshold, new position opened
    EXIT            — detect_exit_triggers() returned should_exit=True
    HOLD            — in-trade, no exit triggered (informational)
    WAIT            — not in-trade, score below entry_threshold (informational)
    COOLDOWN        — not in-trade, in cooldown after recent exit
    STARTUP         — monitor started/resumed (informational)
"""

from __future__ import annotations

import sys
import os
from datetime import datetime
from typing import Callable, Optional

import numpy as np
import pandas as pd

# Ensure project root is on sys.path
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from apollo_core.constants import (
    ENTRY_THRESHOLD, EXIT_THRESHOLD,
    DIVERGENCE_RSI_DROP, DIVERGENCE_COOLDOWN,
)
from apollo_core.trade_engine import detect_exit_triggers
from apollo_core.types import Position, ExitConfig, ExitDecision

from live_engine.data_replay import BarReplay, ReplayBar
from live_engine.state_store import StateStore


# ---------------------------------------------------------------------------
# Alert type constants
# ---------------------------------------------------------------------------

ALERT_ENTRY = "ENTRY"
ALERT_EXIT = "EXIT"
ALERT_HOLD = "HOLD"
ALERT_WAIT = "WAIT"
ALERT_COOLDOWN = "COOLDOWN"
# v4.8: ALERT_GATE_BLOCKED removed — gates are informational only
ALERT_STARTUP = "STARTUP"
ALERT_EXIT_CONFIRMED = "EXIT_CONFIRMED"   # v1.1: emitted by confirm_exit()
ALERT_EXIT_DISMISSED = "EXIT_DISMISSED"   # v1.1: emitted if user dismisses without confirming


# ---------------------------------------------------------------------------
# SignalMonitor
# ---------------------------------------------------------------------------

class SignalMonitor:
    """Live signal monitor for one stock.

    Iterates over bars from a ``BarReplay``, maintains ``Position`` state
    in a ``StateStore``, and emits advisory alerts via a callback.

    Parameters
    ----------
    replay : BarReplay
        Prepared replay instance for the stock to monitor.
    state_store : StateStore
        SQLite-backed state store. Position state is saved after every
        bar, so the monitor can stop/restart without losing state.
    alert_callback : Callable[[dict], None] | None
        Function called for each alert. Receives a dict with keys:
        ``symbol, timestamp, alert_type, message, payload``.
        If None, alerts are only saved to the state store.
    exit_mode : str
        Exit mode for ``detect_exit_triggers()``. Default "NONE" — only
        score-threshold and divergence exits are evaluated. Use
        "FIXED_SL", "TRAILING_SL", "DUAL_SL", or "DI_CROSSOVER" to
        enable other exit types.
    sl_percent : float
        Hard stop-loss percentage (for FIXED_SL / DUAL_SL).
    trailing_sl_percent : float
        Trailing stop-loss percentage (for TRAILING_SL / DUAL_SL).
    trailing_activate_pct : float
        Price-activation threshold for trailing SL (DUAL_SL only).
    divergence_rsi_drop : float
        RSI drop from peak that triggers divergence exit.
    divergence_cooldown_days : int
        Trading days of cooldown after any non-score exit. In live mode,
        cooldown is tracked by DATE (not bar index) — see
        ``Position.cooldown_until_date``.
    auto_confirm_exit : bool
        If True (default for Step 2 backwards-compat), the monitor
        auto-resets position state after emitting an EXIT alert. This
        lets us verify the detect/execute split produces identical
        decisions to the backtest.

        If False (Step 3+ — human-in-the-loop), the monitor sets
        ``pending_exit=True`` and saves the ExitDecision payload to
        ``pending_exit_payload``, but does NOT reset the position.
        Subsequent bars keep updating peaks but skip new exit detection
        (one pending exit at a time). The dashboard's "Confirm Exit"
        button calls :func:`confirm_exit` to reset the position, set
        cooldown, and emit an ``EXIT_CONFIRMED`` alert.
    """

    def __init__(
        self,
        replay: BarReplay,
        state_store: StateStore,
        alert_callback: Optional[Callable[[dict], None]] = None,
        exit_mode: str = "NONE",
        sl_percent: float = 5.0,
        trailing_sl_percent: float = 3.0,
        trailing_activate_pct: float = 5.0,
        divergence_rsi_drop: float = DIVERGENCE_RSI_DROP,
        divergence_cooldown_days: int = DIVERGENCE_COOLDOWN,
        entry_threshold: float = ENTRY_THRESHOLD,
        exit_threshold: float = EXIT_THRESHOLD,
        auto_confirm_exit: bool = True,
    ):
        self.replay = replay
        self.state_store = state_store
        self.alert_callback = alert_callback
        self.auto_confirm_exit = auto_confirm_exit

        self.config = ExitConfig(
            exit_mode=exit_mode,
            sl_percent=sl_percent,
            trailing_sl_percent=trailing_sl_percent,
            trailing_activate_pct=trailing_activate_pct,
            divergence_rsi_drop=divergence_rsi_drop,
            divergence_cooldown=divergence_cooldown_days,
            exit_threshold=exit_threshold,
            entry_threshold=entry_threshold,
        )

        self.symbol = replay.symbol
        self.divergence_cooldown_days = divergence_cooldown_days

        # Loaded on first run() call
        self._position: Optional[Position] = None
        self._last_processed_date: Optional[pd.Timestamp] = None

    # ------------------------------------------------------------------
    # State management
    # ------------------------------------------------------------------

    def _load_state(self) -> None:
        """Load Position + last_processed_date from state_store."""
        self._position, self._last_processed_date = self.state_store.load_position(
            self.symbol
        )

    def _save_state(self, current_date: pd.Timestamp) -> None:
        """Persist current Position + last_processed_date to state_store."""
        self.state_store.save_position(
            self.symbol, self._position, last_processed_date=current_date
        )

    # ------------------------------------------------------------------
    # Alert emission
    # ------------------------------------------------------------------

    def _emit_alert(
        self,
        timestamp: pd.Timestamp,
        alert_type: str,
        message: str,
        payload: Optional[dict] = None,
    ) -> dict:
        """Emit an alert: call callback + save to state_store. Returns the alert dict."""
        alert = {
            "symbol": self.symbol,
            "timestamp": timestamp,
            "alert_type": alert_type,
            "message": message,
            "payload": payload or {},
        }
        if self.alert_callback is not None:
            self.alert_callback(alert)
        self.state_store.save_alert(
            symbol=self.symbol,
            timestamp=timestamp,
            alert_type=alert_type,
            message=message,
            payload=payload,
        )
        return alert

    # ------------------------------------------------------------------
    # Bar processing
    # ------------------------------------------------------------------

    def _build_bar_dict(self, replay_bar: ReplayBar) -> dict:
        """Build the bar dict that detect_exit_triggers expects.

        Mirrors the bar construction in ``extract_trades()``.
        """
        r = replay_bar.daily_result
        df_d = replay_bar.df_d
        date = r["date"]
        close = r["close"]
        rsi = r["rsi21"]

        # Look up open/plus_di/minus_di from df_d (same as extract_trades)
        try:
            open_price = df_d["open"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            open_price = close
        try:
            cur_plus_di = df_d["plus_di"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            cur_plus_di = np.nan
        try:
            cur_minus_di = df_d["minus_di"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            cur_minus_di = np.nan

        return {
            "date": date,
            "close": close,
            "score": r["total"],
            "total": r["total"],
            "rsi": rsi,
            "action": r["action"],
            "open_price": open_price,
            "plus_di": cur_plus_di,
            "minus_di": cur_minus_di,
            "bars_from_trough": r["bars_from_trough"],
            "pool_a": r["pool_a"],
            "pool_b": r["pool_b"],
            "pool_c": r["pool_c"],
            "bonus_a": r["bonus_a"],
            "bonus_b": r["bonus_b"],
            "bonus_c": r["bonus_c"],
            "gates_ok": r.get("gates_ok", True),
            "gate_reasons": r.get("gate_reasons", []),
        }

    def _update_peaks(self, bar: dict, df_d: pd.DataFrame) -> None:
        """Update peak_close and peak_rsi while in trade.

        Mirrors the in-trade state updates in ``extract_trades()``:
          1. peak_close (used by trailing SL)
          2. peak_rsi + peak_rsi_price (used by divergence)
          3. trail_activation (DUAL_SL only)
        """
        close = bar["close"]
        rsi = bar["rsi"]
        date = bar["date"]

        # 1. peak_close
        if close > (self._position.peak_close or -np.inf):
            self._position.peak_close = close

        # 2. peak_rsi
        if self._position.peak_rsi is not None and rsi > self._position.peak_rsi:
            self._position.peak_rsi = rsi
            try:
                self._position.peak_rsi_price = df_d["high"].iloc[df_d.index.get_loc(date)]
            except (KeyError, ValueError):
                self._position.peak_rsi_price = close
            self._position.peak_rsi_date = date

        # 3. trail_activation (DUAL_SL only)
        if (self.config.exit_mode == "DUAL_SL"
                and self._position.trail_activation_price is not None):
            if close >= self._position.trail_activation_price:
                self._position.trail_activation_price = None  # activated

    def _open_position(self, bar: dict) -> None:
        """Open a new position at the current bar's close.

        Mirrors the entry logic in ``extract_trades()``.
        """
        close = bar["close"]
        rsi = bar["rsi"]
        date = bar["date"]
        df_d = self._current_df_d

        self._position.in_trade = True
        self._position.entry_price = close
        self._position.entry_date = date
        self._position.peak_rsi = rsi
        try:
            self._position.peak_rsi_price = df_d["high"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            self._position.peak_rsi_price = close
        self._position.peak_rsi_date = date
        self._position.peak_close = close

        # Set trailing activation threshold for DUAL_SL
        if self.config.exit_mode == "DUAL_SL" and self.config.trailing_activate_pct > 0:
            self._position.trail_activation_price = (
                self._position.entry_price * (1.0 + self.config.trailing_activate_pct / 100.0)
            )
        else:
            self._position.trail_activation_price = None

    def _reset_position_after_exit(self, exit_date: pd.Timestamp,
                                     df_d: Optional[pd.DataFrame] = None) -> None:
        """Reset position to fresh state + set cooldown date.

        Mirrors the reset logic in ``execute_exit()``, but uses
        ``cooldown_until_date`` (a Timestamp) instead of ``cooldown_until``
        (an int bar index), because in live mode the bar index changes
        each day as history grows.

        Cooldown is computed in TRADING DAYS (not calendar days) to match
        the backtest's bar-index-based cooldown exactly. We look up
        ``exit_date`` in ``df_d.index``, advance by ``divergence_cooldown_days``
        positions, and take that date as ``cooldown_until_date``.

        Parameters
        ----------
        exit_date : pd.Timestamp
            Date of the exit bar.
        df_d : pd.DataFrame | None
            Daily DataFrame (used to look up trading-day index). If None,
            falls back to calendar-day approximation (less accurate).
        """
        self._position.in_trade = False
        self._position.entry_price = None
        self._position.entry_date = None
        self._position.peak_rsi = None
        self._position.peak_rsi_price = None
        self._position.peak_rsi_date = None
        self._position.peak_close = None
        self._position.trail_activation_price = None
        # prev_plus_di / prev_minus_di are NOT reset — updated every bar.

        # Cooldown: exit_date + cooldown_days TRADING days.
        # Match the backtest's bar-index-based cooldown exactly.
        if df_d is not None and exit_date in df_d.index:
            exit_idx = df_d.index.get_loc(exit_date)
            # get_loc may return a slice or array if duplicates; coerce to int
            if isinstance(exit_idx, (slice, list, np.ndarray)):
                exit_idx = int(exit_idx[0]) if hasattr(exit_idx, '__getitem__') else int(exit_idx)
            else:
                exit_idx = int(exit_idx)
            cooldown_idx = exit_idx + self.divergence_cooldown_days
            if cooldown_idx < len(df_d.index):
                self._position.cooldown_until_date = df_d.index[cooldown_idx]
            else:
                # Past end of data — set far future (effectively permanent cooldown)
                self._position.cooldown_until_date = (
                    exit_date + pd.Timedelta(days=self.divergence_cooldown_days * 2)
                )
        else:
            # Fallback: calendar-day approximation (only used if df_d unavailable)
            self._position.cooldown_until_date = (
                exit_date + pd.Timedelta(days=self.divergence_cooldown_days)
            )

    def _is_in_cooldown(self, current_date: pd.Timestamp) -> bool:
        """Check if we're currently in the post-exit cooldown period.

        Mirrors the backtest's ``i < cooldown_until`` check (strict less-than).
        If ``current_date == cooldown_until_date``, the cooldown is OVER
        and re-entry is allowed.
        """
        cd = self._position.cooldown_until_date
        return cd is not None and current_date < cd

    # ------------------------------------------------------------------
    # Per-bar processing
    # ------------------------------------------------------------------

    _current_df_d: Optional[pd.DataFrame] = None  # set during process_bar

    def process_bar(self, replay_bar: ReplayBar) -> Optional[dict]:
        """Process one bar: detect exits/entries, emit alerts, update state.

        Returns the alert dict if an alert was emitted, else None.
        """
        bar = self._build_bar_dict(replay_bar)
        self._current_df_d = replay_bar.df_d
        date = bar["date"]
        score = bar["score"]
        close = bar["close"]
        cur_plus_di = bar["plus_di"]
        cur_minus_di = bar["minus_di"]

        emitted_alert: Optional[dict] = None

        # ============================================================
        # IN TRADE — check for exit
        # ============================================================
        if self._position.in_trade:
            # Update peaks (in-trade state updates, same as extract_trades)
            self._update_peaks(bar, replay_bar.df_d)

            # If there's already a pending exit (human-confirm mode), skip
            # new exit detection — the user must confirm or dismiss before
            # we evaluate further. Just emit a HOLD with PENDING_EXIT note.
            if self._position.pending_exit:
                payload = self._position.pending_exit_payload or {}
                message = (
                    f"HOLD (PENDING EXIT) — score {score:.1f} on "
                    f"{date.strftime('%Y-%m-%d')}. Awaiting user confirmation "
                    f"for exit triggered on "
                    f"{payload.get('date', '?')}."
                )
                emitted_alert = self._emit_alert(date, ALERT_HOLD, message, {
                    "date": date.isoformat(),
                    "close": float(close),
                    "score": float(score),
                    "pending_exit": True,
                    "pending_exit_date": payload.get("date"),
                    "pending_exit_reason": payload.get("primary_reason"),
                })
            else:
                # PURE detection — never mutates position
                decision: ExitDecision = detect_exit_triggers(bar, self._position, self.config)

                if decision.should_exit:
                    # --- EXIT alert (advisory) ---
                    # Build reason string same as execute_exit
                    parts = [f"PRIMARY: {decision.primary_reason}"]
                    for reason in decision.all_triggered_reasons:
                        if reason != decision.primary_reason:
                            parts.append(f"ALSO: {reason}")
                    full_reason = " | ".join(parts)

                    pnl_pct = ((decision.fill_price - self._position.entry_price)
                                / self._position.entry_price * 100.0) \
                              if self._position.entry_price else 0.0

                    message = (
                        f"EXIT signal — {decision.primary_class} "
                        f"on {date.strftime('%Y-%m-%d')} at fill {decision.fill_price:.2f} "
                        f"(entry {self._position.entry_price:.2f} on "
                        f"{self._position.entry_date.strftime('%Y-%m-%d') if self._position.entry_date else '?'}"
                        f", P&L {pnl_pct:+.2f}%). Reason: {full_reason}"
                    )

                    payload = {
                        "date": date.isoformat(),
                        "close": float(close),
                        "fill_price": float(decision.fill_price),
                        "score": float(score),
                        "entry_price": float(self._position.entry_price) if self._position.entry_price else None,
                        "entry_date": self._position.entry_date.isoformat() if self._position.entry_date else None,
                        "pnl_pct": round(pnl_pct, 2),
                        "primary_reason": decision.primary_reason,
                        "primary_class": decision.primary_class,
                        "all_triggered_reasons": decision.all_triggered_reasons,
                        "hard_sl_hit": decision.hard_sl_hit,
                        "trail_sl_hit": decision.trail_sl_hit,
                        "div_hit": decision.div_hit,
                        "di_hit": decision.di_hit,
                        "score_hit": decision.score_hit,
                        "bars_from_trough": bar["bars_from_trough"],
                        "pool_a": float(bar["pool_a"]),
                        "pool_b": float(bar["pool_b"]),
                        "pool_c": float(bar["pool_c"]),
                    }
                    emitted_alert = self._emit_alert(date, ALERT_EXIT, message, payload)

                    # Apply the exit
                    if self.auto_confirm_exit:
                        # Step 2 behavior — auto-reset position + set cooldown
                        self._reset_position_after_exit(date, df_d=replay_bar.df_d)
                    else:
                        # Step 3 behavior — mark pending, save payload, do NOT reset.
                        # Subsequent bars will skip exit detection until user confirms.
                        self._position.pending_exit = True
                        self._position.pending_exit_payload = payload
                else:
                    # --- HOLD (informational) ---
                    if score >= 90:
                        hold_type = "HOLD-FULL STRONG"
                    elif score >= 80:
                        hold_type = "HOLD-FULL"
                    elif score >= 70:
                        hold_type = "HOLD-STD"
                    else:
                        hold_type = "WATCHLIST"

                    # Only emit HOLD alerts if score changed category since last bar
                    # (to avoid alert spam). For Step 2 simplicity, emit always.
                    message = (
                        f"{hold_type} — score {score:.1f} on {date.strftime('%Y-%m-%d')} "
                        f"(close {close:.2f}, entry {self._position.entry_price:.2f})"
                    )
                    payload = {
                        "date": date.isoformat(),
                        "close": float(close),
                        "score": float(score),
                        "hold_type": hold_type,
                        "entry_price": float(self._position.entry_price) if self._position.entry_price else None,
                        "entry_date": self._position.entry_date.isoformat() if self._position.entry_date else None,
                        "bars_from_trough": bar["bars_from_trough"],
                    }
                    emitted_alert = self._emit_alert(date, ALERT_HOLD, message, payload)

        # ============================================================
        # NOT IN TRADE — check for entry
        # ============================================================
        else:
            if score >= self.config.entry_threshold:
                if self._is_in_cooldown(date):
                    # --- COOLDOWN (informational) ---
                    cd_date = self._position.cooldown_until_date
                    message = (
                        f"COOLDOWN — score {score:.1f} ≥ {self.config.entry_threshold} "
                        f"on {date.strftime('%Y-%m-%d')}, but in cooldown until "
                        f"{cd_date.strftime('%Y-%m-%d')}. No entry."
                    )
                    payload = {
                        "date": date.isoformat(),
                        "score": float(score),
                        "cooldown_until_date": cd_date.isoformat() if cd_date else None,
                    }
                    emitted_alert = self._emit_alert(date, ALERT_COOLDOWN, message, payload)
                else:
                    # --- ENTRY alert (advisory) ---
                    self._open_position(bar)
                    message = (
                        f"ENTRY signal — score {score:.1f} ≥ {self.config.entry_threshold} "
                        f"on {date.strftime('%Y-%m-%d')} at close {close:.2f}. "
                        f"Position opened (advisory — confirm in your broker terminal)."
                    )
                    payload = {
                        "date": date.isoformat(),
                        "close": float(close),
                        "score": float(score),
                        "action": bar["action"],
                        "entry_price": float(close),
                        "entry_date": date.isoformat(),
                        "bucket": replay_bar.bucket,
                        "is_ipo": replay_bar.is_ipo,
                        "bars_from_trough": bar["bars_from_trough"],
                        "pool_a": float(bar["pool_a"]),
                        "pool_b": float(bar["pool_b"]),
                        "pool_c": float(bar["pool_c"]),
                    }
                    emitted_alert = self._emit_alert(date, ALERT_ENTRY, message, payload)
            else:
                # --- WAIT (informational, score below entry threshold) ---
                # Only emit if score is "close" (within 10 points) to avoid spam
                if score >= self.config.entry_threshold - 10:
                    message = (
                        f"WAIT — score {score:.1f} < {self.config.entry_threshold} "
                        f"on {date.strftime('%Y-%m-%d')} (close {close:.2f}). "
                        f"Approaching entry zone."
                    )
                    payload = {
                        "date": date.isoformat(),
                        "close": float(close),
                        "score": float(score),
                    }
                    emitted_alert = self._emit_alert(date, ALERT_WAIT, message, payload)

        # Always update prev_di's (independent of trade state — same as extract_trades)
        self._position.prev_plus_di = cur_plus_di
        self._position.prev_minus_di = cur_minus_di

        # Persist state after every bar
        self._save_state(date)
        return emitted_alert

    # ------------------------------------------------------------------
    # Main run loop
    # ------------------------------------------------------------------

    def run(self, resume: bool = True, verbose: bool = True) -> dict:
        """Run the monitor over all bars in the replay.

        Parameters
        ----------
        resume : bool
            If True (default), load saved state and skip bars already
            processed (bars with date <= last_processed_date). This
            makes the monitor crash-resilient: stop anytime, restart
            and it picks up where it left off.
            If False, clear saved state and start fresh from bar 0.
        verbose : bool
            If True, print a one-line summary per bar to stdout.

        Returns
        -------
        dict with keys:
            symbol, n_bars_processed, n_alerts, n_entries, n_exits,
            n_holds, n_waits, n_cooldowns, final_in_trade,
            last_processed_date
        """
        # Load or reset state
        if not resume:
            self.state_store.clear_position(self.symbol)
            self._position = Position()
            self._last_processed_date = None
        else:
            self._load_state()

        # Emit STARTUP alert
        startup_msg = (
            f"Monitor started for {self.symbol} at "
            f"{datetime.utcnow().isoformat(timespec='seconds')}Z. "
            f"Resume={resume}, in_trade={self._position.in_trade}, "
            f"last_processed={self._last_processed_date}"
        )
        self._emit_alert(
            pd.Timestamp.utcnow(),
            ALERT_STARTUP,
            startup_msg,
            {"resume": resume, "in_trade": self._position.in_trade},
        )
        if verbose:
            print(f"[STARTUP] {startup_msg}")

        # Counters
        n_processed = 0
        n_skipped = 0
        alert_counts = {
            ALERT_ENTRY: 0, ALERT_EXIT: 0, ALERT_HOLD: 0,
            ALERT_WAIT: 0, ALERT_COOLDOWN: 0, ALERT_STARTUP: 0,
        }

        for replay_bar in self.replay.replay():
            # Skip already-processed bars when resuming
            if (resume and self._last_processed_date is not None
                    and replay_bar.date <= self._last_processed_date):
                n_skipped += 1
                continue

            alert = self.process_bar(replay_bar)
            n_processed += 1
            if alert is not None:
                alert_counts[alert["alert_type"]] = alert_counts.get(alert["alert_type"], 0) + 1
                if verbose:
                    print(f"[{alert['alert_type']}] {alert['message']}")

        # Final summary
        summary = {
            "symbol": self.symbol,
            "n_bars_processed": n_processed,
            "n_bars_skipped": n_skipped,
            "n_alerts": sum(alert_counts.values()),
            "n_entries": alert_counts.get(ALERT_ENTRY, 0),
            "n_exits": alert_counts.get(ALERT_EXIT, 0),
            "n_holds": alert_counts.get(ALERT_HOLD, 0),
            "n_waits": alert_counts.get(ALERT_WAIT, 0),
            "n_cooldowns": alert_counts.get(ALERT_COOLDOWN, 0),
            "final_in_trade": self._position.in_trade,
            "last_processed_date": self._last_processed_date,
        }
        if verbose:
            print()
            print("=" * 60)
            print(f"  MONITOR RUN COMPLETE — {self.symbol}")
            print("=" * 60)
            for k, v in summary.items():
                print(f"  {k:.<30} {v}")
            print("=" * 60)
        return summary


# ===========================================================================
# Module-level helpers — called by the dashboard (or any external caller)
# to confirm or dismiss a pending exit. These operate directly on the
# StateStore, so they work even when the monitor subprocess is not running.
# ===========================================================================

def confirm_exit(
    state_store: "StateStore",
    symbol: str,
    exit_date: Optional[pd.Timestamp] = None,
    df_d: Optional[pd.DataFrame] = None,
    divergence_cooldown_days: int = DIVERGENCE_COOLDOWN,
    user_note: str = "",
) -> bool:
    """Confirm a pending exit: reset position, set cooldown, emit EXIT_CONFIRMED.

    Called by the dashboard's "Confirm Exit" button. Reads the current
    Position from the StateStore, resets it (in_trade=False, entry_*=None,
    peak_*=None), sets ``cooldown_until_date`` based on the pending exit's
    date + ``divergence_cooldown_days`` trading days, clears the pending
    state, and emits an ``EXIT_CONFIRMED`` alert to the alert log.

    Parameters
    ----------
    state_store : StateStore
        Open StateStore instance.
    symbol : str
        NSE stock symbol.
    exit_date : pd.Timestamp | None
        Date to use for cooldown calculation. If None, uses the
        ``date`` field from the pending_exit_payload.
    df_d : pd.DataFrame | None
        Daily DataFrame for trading-day lookup (same as
        ``_reset_position_after_exit`` uses). If None, falls back to
        calendar-day approximation.
    divergence_cooldown_days : int
        Cooldown length in trading days. Default: ``DIVERGENCE_COOLDOWN``.
    user_note : str
        Optional note from the user (e.g., "sold at broker"). Stored
        in the EXIT_CONFIRMED alert payload.

    Returns
    -------
    bool
        True if a pending exit was confirmed, False if there was no
        pending exit to confirm.
    """
    position, last_processed = state_store.load_position(symbol)
    if not position.pending_exit:
        return False

    payload = position.pending_exit_payload or {}
    # Determine the exit date — explicit arg > payload > last_processed
    if exit_date is None:
        exit_date_str = payload.get("date")
        exit_date = pd.Timestamp(exit_date_str) if exit_date_str else last_processed
    if exit_date is None:
        exit_date = pd.Timestamp.utcnow().normalize()

    # Capture details for the EXIT_CONFIRMED alert before resetting
    entry_price = position.entry_price
    entry_date = position.entry_date
    fill_price = payload.get("fill_price")
    pnl_pct = payload.get("pnl_pct")
    primary_reason = payload.get("primary_reason")
    primary_class = payload.get("primary_class")

    # Reset position to fresh state
    position.in_trade = False
    position.entry_price = None
    position.entry_date = None
    position.peak_rsi = None
    position.peak_rsi_price = None
    position.peak_rsi_date = None
    position.peak_close = None
    position.trail_activation_price = None
    position.pending_exit = False
    position.pending_exit_payload = None

    # Compute cooldown_until_date (in trading days, same as monitor)
    cooldown_until_date: Optional[pd.Timestamp] = None
    if df_d is not None and exit_date in df_d.index:
        exit_idx = df_d.index.get_loc(exit_date)
        if isinstance(exit_idx, (slice, list, np.ndarray)):
            exit_idx = int(exit_idx[0]) if hasattr(exit_idx, '__getitem__') else int(exit_idx)
        else:
            exit_idx = int(exit_idx)
        cooldown_idx = exit_idx + divergence_cooldown_days
        if cooldown_idx < len(df_d.index):
            cooldown_until_date = df_d.index[cooldown_idx]
        else:
            cooldown_until_date = exit_date + pd.Timedelta(days=divergence_cooldown_days * 2)
    else:
        # Calendar-day fallback
        cooldown_until_date = exit_date + pd.Timedelta(days=divergence_cooldown_days)
    position.cooldown_until_date = cooldown_until_date

    # Persist
    state_store.save_position(symbol, position, last_processed_date=exit_date)

    # Emit EXIT_CONFIRMED alert
    confirm_payload = {
        "symbol": symbol,
        "exit_date": exit_date.isoformat(),
        "entry_price": float(entry_price) if entry_price else None,
        "entry_date": entry_date.isoformat() if entry_date else None,
        "fill_price": float(fill_price) if fill_price else None,
        "pnl_pct": pnl_pct,
        "primary_reason": primary_reason,
        "primary_class": primary_class,
        "cooldown_until_date": cooldown_until_date.isoformat() if cooldown_until_date else None,
        "user_note": user_note,
        "confirmed_at_utc": datetime.utcnow().isoformat(timespec="seconds"),
    }
    message = (
        f"EXIT CONFIRMED by user for {symbol} — exit on "
        f"{exit_date.strftime('%Y-%m-%d')}, cooldown until "
        f"{cooldown_until_date.strftime('%Y-%m-%d') if cooldown_until_date else '?'}."
    )
    state_store.save_alert(
        symbol=symbol,
        timestamp=exit_date,
        alert_type=ALERT_EXIT_CONFIRMED,
        message=message,
        payload=confirm_payload,
    )
    return True


def dismiss_exit(
    state_store: "StateStore",
    symbol: str,
    user_note: str = "",
) -> bool:
    """Dismiss a pending exit WITHOUT closing the position.

    Called by the dashboard's "Dismiss" button when the user decides
    NOT to act on the exit alert (e.g., they disagree with the signal,
    or want to keep holding). Clears ``pending_exit`` and
    ``pending_exit_payload`` but leaves ``in_trade=True`` and all
    entry/peak fields intact. The monitor will resume normal exit
    detection on the next bar.

    Emits an ``EXIT_DISMISSED`` alert so there's an audit trail.

    Returns
    -------
    bool
        True if a pending exit was dismissed, False if there was no
        pending exit.
    """
    position, last_processed = state_store.load_position(symbol)
    if not position.pending_exit:
        return False

    payload = position.pending_exit_payload or {}
    position.pending_exit = False
    position.pending_exit_payload = None
    state_store.save_position(symbol, position, last_processed_date=last_processed)

    dismiss_payload = {
        "symbol": symbol,
        "dismissed_exit_date": payload.get("date"),
        "primary_reason": payload.get("primary_reason"),
        "user_note": user_note,
        "dismissed_at_utc": datetime.utcnow().isoformat(timespec="seconds"),
    }
    message = (
        f"EXIT DISMISSED by user for {symbol} — keeping position open. "
        f"(Original exit alert: {payload.get('primary_reason', '?')})"
    )
    state_store.save_alert(
        symbol=symbol,
        timestamp=pd.Timestamp.utcnow(),
        alert_type=ALERT_EXIT_DISMISSED,
        message=message,
        payload=dismiss_payload,
    )
    return True
