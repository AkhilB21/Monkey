@echo off
REM ============================================================
REM  Apollo v4.8 — Sync eod2 CSVs into Central Parquet Repository
REM ============================================================
REM
REM  Edit the EOD2_PATH below to point to YOUR eod2 daily data folder.
REM  Example: set EOD2_PATH=C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\eod2-main\eod2-main\src\eod2_data\daily
REM

set EOD2_PATH=C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\eod2-main\eod2-main\src\eod2_data\daily
set REPO_DIR=apollo_data

echo.
echo ============================================================
echo   APOLLO v4.8 — DATA SYNC (eod2 CSVs -^> Parquet)
echo ============================================================
echo   Source: %EOD2_PATH%
echo   Repo:   %REPO_DIR%
echo.

python -m data_repo.sync --source-dir "%EOD2_PATH%" --repo-dir %REPO_DIR% --update

echo.
echo Sync complete. Now run:
echo   streamlit run backtest_engine\app.py
echo   OR
echo   python -m live_engine
echo.
pause
