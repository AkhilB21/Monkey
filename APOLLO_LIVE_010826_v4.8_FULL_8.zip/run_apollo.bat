@echo off
title Apollo Backtest Studio
echo ===================================================
echo   Apollo Backtest Studio - Starting...
echo ===================================================
echo.

:: Activate your Python environment if you use one (uncomment if needed)
:: call C:\Users\Akhilesh Bhardwaj\anaconda3\Scripts\activate.bat
:: call C:\Users\Akhilesh Bhardwaj\miniconda3\Scripts\activate.bat
:: call C:\Users\Akhilesh Bhardwaj\envs\apollo\Scripts\activate.bat

cd /d "%~dp0"
streamlit run backtest_engine\app.py --server.headless true

if %errorlevel% neq 0 (
    echo.
    echo ERROR: Something went wrong.
    echo Make sure you have installed requirements:
    echo   pip install -r requirements.txt
    echo.
    pause
)
