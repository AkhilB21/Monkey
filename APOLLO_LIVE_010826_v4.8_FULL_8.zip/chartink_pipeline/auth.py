"""Chartink Authentication — One-time login via Playwright.

Run this ONCE to log into Chartink. It saves your session cookies so
that all subsequent API calls (chartink_fetcher.py) work without login.

Usage:
    python -m chartink_pipeline.auth           # Shows browser for login
    python -m chartink_pipeline.auth --headless # Headless (VPS with display)

After successful login, the file ``chartink_state.json`` is created in the
``chartink_pipeline/`` directory. Keep this file secure — it contains your
Chartink session.

Session Lifetime:
    Chartink sessions typically last 30-60 days. If the fetcher starts
    returning 0 results or 419 errors, re-run this script to refresh.

IMPORTANT — How login detection works:
    The script waits for the browser to land on chartink.com (NOT google.com
    or any other OAuth provider). It then verifies login by checking for
    a logged-in page element (user avatar/menu). Only after verification
    does it save the session state.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlparse

# Resolve paths relative to THIS file (chartink_pipeline/auth.py)
_THIS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent  # apollo_engine/
STATE_FILE = _THIS_DIR / "chartink_state.json"


def _is_chartink_page(url: str) -> bool:
    """Check if URL's hostname is chartink.com (not a substring in params)."""
    try:
        parsed = urlparse(url)
        return parsed.hostname == "chartink.com"
    except Exception:
        return False


def _is_login_or_auth_page(url: str) -> bool:
    """Check if we're still on a login/auth/callback page."""
    try:
        parsed = urlparse(url)
        path = parsed.path.lower()
        return (
            "/login" in path
            or "/auth/" in path
            or parsed.hostname != "chartink.com"
        )
    except Exception:
        return True


def login(headless: bool = False) -> bool:
    """Open a Chromium browser, let user log into Chartink, save state."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print(
            "ERROR: playwright not installed.\n"
            "  pip install playwright\n"
            "  playwright install chromium",
            file=sys.stderr,
        )
        return False

    print("\n" + "=" * 60)
    print("  CHARTINK LOGIN — One-Time Setup")
    print("=" * 60)
    print("\nA Chromium browser will open. Please:")
    print("  1. Log into your Chartink account (Google OAuth)")
    print("  2. Wait until you see the Chartink Dashboard/Screener page")
    print("  3. This script will auto-detect login and save state")
    print()

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=headless,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"],
        )
        context = browser.new_context(
            viewport={"width": 1280, "height": 800},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/131.0.0.0 Safari/537.36"
            ),
        )
        page = context.new_page()

        # Navigate to login
        page.goto("https://chartink.com/login", wait_until="networkidle")
        print(f"Browser opened. Current URL: {page.url}")

        print("Waiting for you to complete login...")
        print("(Script will auto-detect when login succeeds)\n")

        login_detected = False
        try:
            # CRITICAL FIX: Use hostname check, NOT substring.
            # The old code used "chartink.com" in url which matched Google's
            # OAuth URL (which has chartink.com in the redirect_uri parameter).
            page.wait_for_url(
                lambda url: (
                    _is_chartink_page(url)
                    and not _is_login_or_auth_page(url)
                ),
                timeout=300_000,
            )
            print(f"\nRedirected to Chartink: {page.url}")
            login_detected = True
        except Exception:
            print("\nAuto-detection timeout (5 min).")
            print("Press Enter after you've logged in and see the Dashboard...")
            try:
                input()
                login_detected = True
            except (EOFError, KeyboardInterrupt):
                print("\nCancelled.")
                browser.close()
                return False

        if not login_detected:
            browser.close()
            return False

        # Wait for the page to fully load after redirect
        print("Waiting for page to load...")
        try:
            page.wait_for_load_state("networkidle", timeout=15000)
        except Exception:
            pass  # Some pages never fully idle, that's OK

        # EXTRA WAIT: OAuth callback may need time to set authenticated cookies
        print("Waiting for session cookies to be set...")
        page.wait_for_timeout(5000)

        # VERIFY LOGIN: Check for logged-in indicators
        print("Verifying authentication...")
        logged_in = False

        # Method 1: Look for user avatar/menu (common in Chartink UI)
        selectors_to_try = [
            'img[alt*="avatar" i]',
            'img[alt*="profile" i]',
            '.user-menu',
            '.user-avatar',
            '.dropdown-toggle',
            'a[href*="profile"]',
            'a[href*="logout"]',
            'button:has-text("Logout")',
            'a:has-text("Logout")',
            '.navbar-right .dropdown',
            '[data-toggle="dropdown"]',
        ]
        for sel in selectors_to_try:
            try:
                elem = page.locator(sel).first
                if elem.is_visible(timeout=2000):
                    print(f"  Found logged-in element: {sel}")
                    logged_in = True
                    break
            except Exception:
                continue

        # Method 2: Check if we're NOT on login/error page
        if not logged_in:
            current_url = page.url
            if _is_chartink_page(current_url) and not _is_login_or_auth_page(current_url):
                # We're on a chartink page that's not login/auth — likely logged in
                print(f"  On Chartink page (not login): {current_url}")
                logged_in = True

        # Method 3: Check if the page has screener/dashboard content
        if not logged_in:
            try:
                page_content = page.content()
                if 'screener' in page_content.lower() or 'dashboard' in page_content.lower():
                    if '/login' not in page.url.lower():
                        logged_in = True
                        print("  Page contains screener/dashboard content")
            except Exception:
                pass

        if not logged_in:
            print("\nWARNING: Could not verify login.")
            print("The session may not work properly.")
            print("You can try again, or check if Chartink loaded correctly.")

        # Navigate to screener to ensure we have a valid page context
        # This also refreshes the XSRF token
        print("\nNavigating to screener to finalize session...")
        try:
            page.goto("https://chartink.com/screener", wait_until="domcontentloaded", timeout=30000)
            page.wait_for_timeout(3000)
            print(f"  Screener page loaded: {page.url}")
        except Exception as e:
            print(f"  Warning: Could not load screener page: {e}")

        # Save browser state AFTER full authentication
        context.storage_state(path=str(STATE_FILE))
        print(f"\nSession saved to: {STATE_FILE}")

        # Verify saved cookies
        with open(STATE_FILE) as f:
            saved_state = json.load(f)

        cookies = saved_state.get("cookies", [])
        xsrf = next((c["value"] for c in cookies if c["name"] == "XSRF-TOKEN"), "")
        ci_session = next((c["value"] for c in cookies if c["name"] == "ci_session"), "")
        all_domains = set(c.get("domain", "") for c in cookies)

        print(f"  Cookies saved: {len(cookies)}")
        print(f"  Domains: {all_domains}")
        if xsrf:
            print(f"  XSRF-TOKEN: present ({len(xsrf)} chars)")
        else:
            print("  XSRF-TOKEN: MISSING")
        if ci_session:
            print(f"  ci_session:  present ({len(ci_session)} chars)")
        else:
            print("  ci_session:  MISSING")

        if xsrf and ci_session:
            print("\nAuthentication setup complete!")
            print("You can now run the pipeline without logging in again.")
            success = True
        else:
            print("\nWARNING: Expected cookies are missing.")
            print("The session may not work. Try logging in again.")
            success = False

        browser.close()
        return success


def load_state() -> dict | None:
    """Load saved browser state. Returns None if not found."""
    if not STATE_FILE.exists():
        return None
    with open(STATE_FILE) as f:
        return json.load(f)


def is_authenticated() -> bool:
    """Check if a valid session state file exists."""
    state = load_state()
    if not state:
        return False
    cookies = state.get("cookies", [])
    has_xsrf = any(c["name"] == "XSRF-TOKEN" for c in cookies)
    has_session = any(c["name"] == "ci_session" for c in cookies)
    return has_xsrf and has_session


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Chartink one-time login")
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run browser in headless mode (for VPS)",
    )
    args = parser.parse_args(argv)
    ok = login(headless=args.headless)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
