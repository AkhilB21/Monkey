"""Chartink API Diagnostic v3 — Network interceptor + UI automation test.

This script:
  1. Opens the browser with saved session
  2. Sets up a network interceptor to capture EXACT request/response
  3. Tests the UI automation approach (fill form, click Scan)
  4. Falls back to API methods if UI fails
  5. Reports column names, data samples, and request details

Usage:
    python -m chartink_pipeline.diagnose
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

_THIS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from chartink_pipeline.fetcher import ChartinkClient, ChartinkAPIError


def main():
    print("=" * 60)
    print("  CHARTINK API DIAGNOSTIC (v3 — UI automation + interceptor)")
    print("=" * 60)

    client = None
    try:
        # 1. Load session
        print("\n[1] Loading session...")
        try:
            client = ChartinkClient()
            print("  Session file loaded OK")
        except FileNotFoundError as e:
            print(f"  FAIL: {e}")
            return 1

        # 2. Test with a simple condition via UI automation
        print("\n[2] Running scan via UI automation: ( close greater than 0 )")
        try:
            df = client.run_scan(
                scan_condition="( close greater than 0 )",
                process="daily",
                sort_col="% change",
                sort_order="desc",
                max_rows=5,
            )
            if df.empty:
                print("  UI automation returned 0 rows")
                print("  Trying API fallbacks...")
            else:
                print(f"  SUCCESS: {len(df)} rows returned")
                print(f"  Columns ({len(df.columns)}): {list(df.columns)}")
                print(f"\n  First row:")
                for col in df.columns:
                    val = df.iloc[0][col]
                    print(f"    {col:45s} = {val}")
        except ChartinkAPIError as e:
            print(f"  FAIL (API error): {e}")
            return 1
        except Exception as e:
            print(f"  FAIL: {e}")
            return 1

        # 3. Test RSI condition
        print("\n[3] Running RSI scan: RSI(21,36,56) on daily...")
        rsi_condition = (
            "( ( RSI ( 21 , C ) greater than 0 ) "
            "and ( RSI ( 36 , C ) greater than 0 ) "
            "and ( RSI ( 56 , C ) greater than 0 ) )"
        )
        try:
            df2 = client.run_scan(
                scan_condition=rsi_condition,
                process="daily",
                sort_col="% change",
                sort_order="desc",
                max_rows=5,
            )
            if df2.empty:
                print("  0 rows returned")
            else:
                print(f"  SUCCESS: {len(df2)} rows returned")
                print(f"  Columns ({len(df2.columns)}): {list(df2.columns)}")

                rsi_cols = [c for c in df2.columns if 'rsi' in str(c).lower()]
                print(f"  RSI columns found: {rsi_cols}")

                print(f"\n  First row (key columns):")
                for col in df2.columns:
                    col_l = str(col).lower()
                    if any(k in col_l for k in [
                        'rsi', 'change', 'close', 'nsecode',
                        'name', 'volume', 'symbol'
                    ]):
                        val = df2.iloc[0][col]
                        print(f"    {col:45s} = {val}")
        except Exception as e:
            print(f"  FAIL: {e}")

        # 4. Test NIFTY 500 condition
        print("\n[4] Running NIFTY 500 scan...")
        try:
            df3 = client.run_scan(
                scan_condition="( NIFTY 500 index constituent is true )",
                process="daily",
                sort_col="% change",
                sort_order="desc",
                max_rows=5,
            )
            if df3.empty:
                print("  0 rows (may be free tier limitation or market closed)")
            else:
                print(f"  SUCCESS: {len(df3)} rows returned")
        except Exception as e:
            print(f"  FAIL: {e}")

        # 5. Test intraday
        print("\n[5] Running RSI scan on 15min...")
        try:
            df4 = client.run_scan(
                scan_condition=rsi_condition,
                process="15min",
                sort_col="% change",
                sort_order="desc",
                max_rows=3,
            )
            if df4.empty:
                print("  0 rows (market may be closed for intraday)")
            else:
                print(f"  SUCCESS: {len(df4)} rows returned")
        except Exception as e:
            print(f"  FAIL: {e}")

        # 6. DOM inspection summary
        print("\n[6] Page DOM inspection...")
        try:
            client._ensure_browser()
            dom_info = client._page.evaluate("""() => {
                const info = {};

                // Check for textareas
                const textareas = document.querySelectorAll('textarea');
                info.textareas = Array.from(textareas).map(t => ({
                    id: t.id, name: t.name,
                    className: t.className,
                    visible: t.offsetParent !== null,
                    rows: t.rows,
                }));

                // Check for CodeMirror
                const cm = document.querySelector('.CodeMirror, .cm-editor');
                info.hasCodeMirror = !!cm;
                if (cm) {
                    info.codeMirrorClass = cm.className;
                }

                // Check for select dropdowns
                const selects = document.querySelectorAll('select');
                info.selects = Array.from(selects).map(s => ({
                    id: s.id, name: s.name,
                    options: Array.from(s.options).map(o => ({
                        value: o.value, text: o.text
                    })),
                }));

                // Check for buttons
                const buttons = document.querySelectorAll('button, input[type="submit"]');
                info.buttons = Array.from(buttons).map(b => ({
                    tag: b.tagName,
                    type: b.type,
                    text: (b.textContent || b.value || '').trim().substring(0, 50),
                    className: b.className.substring(0, 50),
                }));

                // Check for tables
                const tables = document.querySelectorAll('table');
                info.tables = Array.from(tables).map(t => ({
                    id: t.id,
                    className: t.className,
                    rows: t.querySelectorAll('tbody tr').length,
                    cols: t.querySelectorAll('thead th').length,
                }));

                return info;
            }""")

            print(f"  Textareas found: {len(dom_info.get('textareas', []))}")
            for ta in dom_info.get('textareas', []):
                print(f"    id={ta['id']!r} name={ta['name']!r} "
                      f"visible={ta['visible']} rows={ta['rows']}")

            print(f"  CodeMirror: {dom_info.get('hasCodeMirror', False)}")

            print(f"  Select dropdowns: {len(dom_info.get('selects', []))}")
            for sel in dom_info.get('selects', []):
                opts = sel.get('options', [])
                print(f"    id={sel['id']!r} name={sel['name']!r} "
                      f"options={[o['value'] for o in opts[:5]]}...")

            print(f"  Buttons: {len(dom_info.get('buttons', []))}")
            for btn in dom_info.get('buttons', []):
                print(f"    <{btn['tag']}> text={btn['text']!r}")

            print(f"  Tables: {len(dom_info.get('tables', []))}")
            for tbl in dom_info.get('tables', []):
                print(f"    id={tbl['id']!r} rows={tbl['rows']} cols={tbl['cols']}")

        except Exception as e:
            print(f"  DOM inspection failed: {e}")

        print("\n" + "=" * 60)
        print("  DIAGNOSTIC COMPLETE")
        print("  If tests 2-3 returned data, the pipeline should work.")
        print("  If DOM inspection shows form elements, UI automation")
        print("  will use them on next run.")
        print("=" * 60)
        return 0

    finally:
        if client:
            client.close()


if __name__ == "__main__":
    sys.exit(main())
