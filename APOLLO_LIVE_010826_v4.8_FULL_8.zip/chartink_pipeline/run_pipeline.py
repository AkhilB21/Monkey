"""Chartink -> Apollo Pipeline — Main runner.

Fetches data from Chartink dashboards, scores stocks, and updates
Apollo's my_watchlist.json with curated candidates.

Usage:
    # Full pipeline (fetch + score + update watchlist)
    python -m chartink_pipeline.run_pipeline

    # Preview only (don't modify watchlist)
    python -m chartink_pipeline.run_pipeline --dry-run

    # Just fetch and save raw data
    python -m chartink_pipeline.run_pipeline --fetch-only

    # Relaxed filters
    python -m chartink_pipeline.run_pipeline --threshold 30 --max 200

VPS Cron (daily at 3:35 PM IST, after market close):
    35 15 * * 1-5 cd /path/to/apollo_engine && python -m chartink_pipeline.run_pipeline >> logs/chartink.log 2>&1

Output:
    chartink_output/raw/<timestamp>/       -- Raw CSVs from Chartink
    chartink_output/chartink_curated_watchlist.json  -- Curated watchlist
    chartink_output/chartink_apollo_ranked_*.csv     -- Recovery ranked report
    chartink_output/chartink_momentum_ranked_*.csv   -- Momentum ranked report
    chartink_output/pipeline_summary_*.json           -- Summary (both tables)
    my_watchlist.json (updated in-place, backup created)
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

# Paths relative to THIS file inside apollo_engine/chartink_pipeline/
_THIS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent  # apollo_engine/
_DEFAULT_WATCHLIST = _PROJECT_ROOT / "my_watchlist.json"
_DEFAULT_DATA_DIR = _PROJECT_ROOT / "data"
_DEFAULT_OUTPUT_DIR = _PROJECT_ROOT / "chartink_output"

# Add project root to sys.path so imports work regardless of cwd
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from chartink_pipeline.fetcher import (
    ChartinkClient,
    ChartinkAPIError,
    fetch_rsi_dashboard,
    fetch_nifty500_gainers,
)
from chartink_pipeline.watchlist_generator import ChartinkApolloBridge


# -- Helpers -----------------------------------------------------------


def save_raw_data(rsi_data, gainer_data, output_dir, timestamp):
    """Save raw Chartink API responses for debugging."""
    raw_dir = output_dir / "raw" / timestamp
    raw_dir.mkdir(parents=True, exist_ok=True)
    for tf_name, df in rsi_data.items():
        if not df.empty:
            df.to_csv(raw_dir / f"rsi_{tf_name}.csv", index=False)
    for tf_name, df in gainer_data.items():
        if not df.empty:
            df.to_csv(raw_dir / f"nifty500_{tf_name}.csv", index=False)
    raw_json = {
        "timestamp": timestamp,
        "rsi_timeframes": {k: len(v) for k, v in rsi_data.items()},
        "gainer_timeframes": {k: len(v) for k, v in gainer_data.items()},
    }
    with open(raw_dir / "fetch_summary.json", "w") as f:
        json.dump(raw_json, f, indent=2)
    print(f"  Raw data saved to: {raw_dir}")


def merge_into_apollo_watchlist(
    watchlist: list[dict],
    watchlist_path: Path = _DEFAULT_WATCHLIST,
    backup_existing: bool = True,
) -> str:
    """Merge Chartink-curated stocks into Apollo's my_watchlist.json.

    This MERGES (doesn't replace) -- existing entries are preserved.
    New stocks from Chartink are appended. Duplicates are skipped.
    A .json.bak backup is created before any modification.
    """
    existing = []
    if watchlist_path.exists():
        if backup_existing:
            backup_path = watchlist_path.with_suffix(".json.bak")
            shutil.copy2(watchlist_path, backup_path)
            print(f"  Backed up existing watchlist to: {backup_path}")
        try:
            with open(watchlist_path) as f:
                existing = json.load(f)
        except (json.JSONDecodeError, IOError):
            existing = []

    existing_syms = {
        e.get("sym", "").replace(".NS", "").upper() for e in existing
    }

    apollo_wl = list(existing)
    new_count = 0
    for entry in watchlist:
        sym = entry.get("sym", "").replace(".NS", "").upper()
        if sym not in existing_syms:
            apollo_wl.append({
                "sym": entry["sym"],
                "name": entry.get("name", sym),
                "sector": entry.get("sector", ""),
            })
            existing_syms.add(sym)
            new_count += 1

    with open(watchlist_path, "w") as f:
        json.dump(apollo_wl, f, indent=2)

    print(f"  Apollo watchlist updated: {watchlist_path}")
    print(f"    Existing entries: {len(existing)}")
    print(f"    New from Chartink: {new_count}")
    print(f"    Total: {len(apollo_wl)}")
    return str(watchlist_path)


# -- Pipeline -------------------------------------------------------------


def run_pipeline(
    apollo_dir: str = "",
    output_dir: str = "",
    dry_run: bool = False,
    fetch_only: bool = False,
    recovery_threshold: float = 40.0,
    max_watchlist: int = 100,
) -> dict:
    """Execute the full Chartink -> Apollo pipeline.

    Returns a result dict with status, counts, and output paths.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d_%H%M")

    project_root = Path(apollo_dir) if apollo_dir else _PROJECT_ROOT
    out_dir = Path(output_dir) if output_dir else _DEFAULT_OUTPUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)

    result = {"timestamp": timestamp, "status": "started", "errors": []}

    print("=" * 60)
    print(f"  CHARTINK -> APOLLO PIPELINE")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S IST')}")
    print("=" * 60)

    # Step 1: Initialize Chartink client (Playwright-based)
    print("\n[1/5] Connecting to Chartink...")
    client = None
    try:
        client = ChartinkClient()
    except FileNotFoundError as e:
        msg = f"Setup required: {e}"
        print(f"  ERROR: {msg}")
        print("  Run: python -m chartink_pipeline.auth")
        result["status"] = "auth_required"
        result["errors"].append(msg)
        return result
    except Exception as e:
        msg = f"Failed to initialize: {e}"
        print(f"  ERROR: {msg}")
        result["status"] = "error"
        result["errors"].append(msg)
        return result

    try:
        # Step 2: Fetch data
        print("\n[2/5] Fetching RSI Dashboard data (6 timeframes)...")
        try:
            rsi_data = fetch_rsi_dashboard(client)
            rsi_total = sum(len(v) for v in rsi_data.values())
            print(f"  RSI Dashboard: {rsi_total} total rows across 6 timeframes")
        except ChartinkAPIError as e:
            # Only abort if it's a real auth error (419/401/session expired)
            msg_lower = str(e).lower()
            is_auth = any(kw in msg_lower for kw in [
                "419", "401", "csrf", "session expired",
                "authentication failed", "redirected to login",
            ])
            if is_auth:
                msg = f"RSI fetch failed (auth): {e}"
                print(f"  ERROR: {msg}")
                result["status"] = "auth_expired"
                result["errors"].append(msg)
                return result
            else:
                # Non-auth error (timeout, no data, UI element not found)
                msg = f"RSI fetch failed: {e}"
                print(f"  WARNING: {msg}")
                result["errors"].append(msg)
                rsi_data = {}
        except Exception as e:
            msg = f"RSI fetch failed: {e}"
            print(f"  WARNING: {msg}")
            result["errors"].append(msg)
            rsi_data = {}

        print("\n[2/5] Fetching NIFTY 500 Gainers data (6 timeframes)...")
        try:
            gainer_data = fetch_nifty500_gainers(client)
            gainer_total = sum(len(v) for v in gainer_data.values())
            print(
                f"  NIFTY 500 Gainers: {gainer_total} total rows across 6 timeframes"
            )
        except Exception as e:
            msg = f"Gainer fetch failed: {e}"
            print(f"  WARNING: {msg}")
            result["errors"].append(msg)
            gainer_data = {}

        save_raw_data(rsi_data, gainer_data, out_dir, timestamp)
        result["rsi_rows"] = {k: len(v) for k, v in rsi_data.items()}
        result["gainer_rows"] = {k: len(v) for k, v in gainer_data.items()}

        if fetch_only:
            print("\n[FETCH-ONLY] Raw data saved. Skipping Apollo integration.")
            result["status"] = "fetch_only"
            return result

        # Step 3: Process
        print("\n[3/6] Processing RSI Dashboard...")
        apollo_data_dir = project_root / "data"
        bridge = ChartinkApolloBridge(
            apollo_data_dir=str(apollo_data_dir),
            output_dir=str(out_dir),
        )
        rsi_df = bridge.process_rsi_dashboard(rsi_data)
        print(f"  Unique stocks from RSI dashboard: {len(rsi_df)}")

        print("\n[3/6] Processing NIFTY 500 Gainers...")
        gainer_df = bridge.process_nifty500_gainers(gainer_data)
        print(f"  Unique stocks from NIFTY 500 Gainers: {len(gainer_df)}")

        # Step 4: Generate Recovery Watchlist + Momentum Table
        print("\n[4/6] Cross-referencing and generating recovery watchlist...")
        ranked_df, watchlist = bridge.generate_apollo_watchlist(
            rsi_df=rsi_df,
            gainer_df=gainer_df,
            recovery_threshold=recovery_threshold,
            max_watchlist=max_watchlist,
        )

        print("\n[4/6] Generating momentum candidates table...")
        momentum_df = bridge.generate_momentum_table(
            gainer_df=gainer_df, rsi_df=rsi_df,
        )
        # Enrich momentum table with price range
        momentum_df = bridge.enrich_with_price_range(momentum_df)

        if not watchlist:
            print("  WARNING: No stocks passed all filters.")
            print(f"  Try lowering --threshold (current: {recovery_threshold})")
            result["status"] = "empty_watchlist"
            result["watchlist_count"] = 0
            return result

        # Step 5: Save + Update Apollo
        print("\n[5/6] Saving outputs...")
        saved_paths = bridge.save_outputs(
            ranked_df, watchlist, momentum_df=momentum_df, timestamp=timestamp,
        )
        result["outputs"] = saved_paths
        result["watchlist_count"] = len(watchlist)
        result["momentum_count"] = len(momentum_df)
        result["with_apollo_data"] = sum(
            1 for w in watchlist if w.get("has_apollo_data")
        )

        if not dry_run:
            print("\n[6/6] Updating Apollo my_watchlist.json...")
            wl_path = merge_into_apollo_watchlist(watchlist)
            result["apollo_watchlist"] = wl_path
        else:
            print("\n  [DRY RUN] Would update Apollo watchlist (skipped)")

        print("\n" + "=" * 60)
        print("  TOP 10 RECOVERY CANDIDATES")
        print("=" * 60)
        for w in watchlist[:10]:
            flag = "[HAS DATA]" if w.get("has_apollo_data") else "[no data]"
            print(
                f"  {w['sym']:<14s} score={w.get('chartink_score', '?'):>5.1f}  "
                f"{w.get('momentum_type', ''):<22s} {flag}"
            )
        print("=" * 60)

        if not momentum_df.empty:
            print("\n  TOP 10 MOMENTUM CANDIDATES")
            print("  " + "-" * 58)
            for _, row in momentum_df.head(10).iterrows():
                print(
                    f"  {row['symbol']:<14s} mom_score={row.get('momentum_score', 0):>5.1f}  "
                    f"{row.get('momentum_type', ''):<22s} "
                    f"cascade={row.get('rsi_cascade', '')}"
                )
            print("  " + "-" * 58)

        result["status"] = "success"
        return result
    finally:
        # Always release Playwright browser resources
        if client:
            client.close()
            print("\n  Browser closed.")


# -- CLI ------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="apollo-chartink",
        description="Chartink -> Apollo automated watchlist curation pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\nExamples:
  python -m chartink_pipeline.run_pipeline                              # Full pipeline
  python -m chartink_pipeline.run_pipeline --dry-run                   # Preview only
  python -m chartink_pipeline.run_pipeline --fetch-only                 # Just fetch data
  python -m chartink_pipeline.run_pipeline --threshold 30 --max 200      # Relaxed filters

VPS Cron (daily at 3:35 PM IST):
  35 15 * * 1-5 cd /path/to/apollo_engine && \\
    python -m chartink_pipeline.run_pipeline >> logs/chartink.log 2>&1\n        """,
    )
    parser.add_argument(
        "--apollo-dir", type=str, default="",
        help="Path to Apollo engine root (auto-detected if inside apollo_engine/)",
    )
    parser.add_argument(
        "--output-dir", type=str, default="",
        help="Output directory (default: chartink_output/)",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Fetch and analyze, but do NOT modify my_watchlist.json",
    )
    parser.add_argument(
        "--fetch-only", action="store_true",
        help="Only fetch and save raw Chartink data",
    )
    parser.add_argument(
        "--threshold", type=float, default=40.0,
        help="Min recovery score (0-100, default: 40)",
    )
    parser.add_argument(
        "--max", type=int, default=100,
        help="Max stocks in output watchlist (default: 100)",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    result = run_pipeline(
        apollo_dir=args.apollo_dir,
        output_dir=args.output_dir,
        dry_run=args.dry_run,
        fetch_only=args.fetch_only,
        recovery_threshold=args.threshold,
        max_watchlist=args.max,
    )

    if result["status"] == "success":
        print(f"\nPipeline completed: {result['watchlist_count']} stocks curated")
        if result.get("with_apollo_data", 0) > 0:
            print(
                f"  ({result['with_apollo_data']} have Apollo CSV data for full scoring)"
            )
        return 0
    elif result["status"] in ("auth_required", "auth_expired"):
        print("\nAction: Re-run authentication")
        print("  python -m chartink_pipeline.auth")
        return 2
    else:
        print(f"\nPipeline finished with status: {result['status']}")
        for err in result.get("errors", []):
            print(f"  Error: {err}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
