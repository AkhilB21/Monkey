"""Allow running as: python -m chartink_pipeline"""
from chartink_pipeline.run_pipeline import main
import sys
sys.exit(main())
