"""Apollo Data Sync — import/update data into the Parquet repository (v4.8)

Usage:
    python -m data_repo.sync --eod2-dir /path/to/eod2/csvs  # initial import
    python -m data_repo.sync --eod2-dir /path/to/eod2/csvs --update  # smart merge

Smart merge (—update):
    1. Read existing Parquet (if any) to get last_date.
    2. Read source CSV, filter to rows with Date > last_date.
    3. Append new rows, deduplicate on Date, re-sort, write back.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from data_repo.sources import load_eod2_csv
from data_repo.repo import load_daily, save_daily


def sync_eod2_dir(
    eod2_dir: str | Path,
    repo_dir: str | Path | None = None,
    update: bool = False,
) -> dict:
    """Import or update all eod2 CSVs into the Parquet repository.

    Parameters
    ----------
    eod2_dir : str or Path
        Directory containing {SYMBOL}.csv files in eod2 format.
    repo_dir : str or Path or None
        Target Parquet repository directory. Default: apollo_data/.
    update : bool
        If True, only append new bars (smart merge). If False,
        overwrite the entire Parquet file.

    Returns
    -------
    dict with keys: imported, updated, skipped, errors.
    """
    eod2_path = Path(eod2_dir)
    if not eod2_path.exists():
        return {"imported": 0, "updated": 0, "skipped": 0, "errors": [f"eod2 dir not found: {eod2_path}"]}

    stats = {"imported": 0, "updated": 0, "skipped": 0, "errors": []}

    for csv_file in sorted(eod2_path.glob("*.csv")):
        symbol = csv_file.stem.upper()
        try:
            source_df = load_eod2_csv(csv_file)
            if source_df.empty:
                stats["skipped"] += 1
                continue

            if update:
                try:
                    existing = load_daily(repo_dir, symbol)
                except FileNotFoundError:
                    existing = pd.DataFrame()
                if not existing.empty:
                    last_date = existing.index.max()
                    new_rows = source_df[source_df.index > last_date]
                    if new_rows.empty:
                        stats["skipped"] += 1
                        continue
                    merged = pd.concat([existing, new_rows])
                    merged = merged[~merged.index.duplicated(keep="last")]
                    merged = merged.sort_index()
                    save_daily(repo_dir, symbol, merged, source="eod2")
                    stats["updated"] += 1
                    continue

            # Full import
            save_daily(repo_dir, symbol, source_df, source="eod2")
            stats["imported"] += 1
        except Exception as e:
            stats["errors"].append(f"{symbol}: {e}")

    return stats


def main():
    parser = argparse.ArgumentParser(description="Sync eod2 CSVs into Apollo Parquet repository")
    parser.add_argument("--eod2-dir", "--source-dir", required=True, help="Directory with eod2 CSVs")
    parser.add_argument("--repo-dir", default=None, help="Target Parquet repo dir (default: apollo_data/)")
    parser.add_argument("--update", action="store_true", help="Smart merge: only append new bars")
    args = parser.parse_args()

    stats = sync_eod2_dir(args.eod2_dir, args.repo_dir, args.update)
    print(f"Imported: {stats['imported']}, Updated: {stats['updated']}, "
          f"Skipped: {stats['skipped']}, Errors: {len(stats['errors'])}")
    for err in stats["errors"]:
        print(f"  ERROR: {err}")


if __name__ == "__main__":
    main()
